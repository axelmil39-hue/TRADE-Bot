# Signal-Desk

Dein eigener Trading-Bot mit Dashboard. Er scannt rund um die Uhr die 100 größten Kryptos (ohne Stablecoins) sowie Gold, Silber, Rohöl und Erdgas, meldet Signale per Telegram und zeigt alles auf einer eigenen Webseite. Du kannst mit ihm sprechen.

Der Bot **handelt nicht selbst**. Er liefert Signale mit Einstieg, Stop-Loss und zwei Kurszielen und führt ein Logbuch mit Trefferquote. Keine Anlageberatung.

## Was im Dashboard steckt

| Bereich | Inhalt |
|---|---|
| Chart | Kerzen, Volumen, EMA 50/200, Volumenprofil, Fibonacci, Support/Widerstand, erkannte Muster, Handelsplan. Mausrad zoomt, Ziehen verschiebt, Doppelklick setzt zurück. |
| Signal-Urteil | Die „Tauziehen“-Leiste zeigt, wie viele Kriterien bullisch (links) und bärisch (rechts) sind. Ab der Markierung (Standard: 3) wird es ein Signal. |
| Kriterien | Alle 10 Kriterien mit Befund in Klartext. |
| Scanner | Alle Märkte und Zeiteinheiten, sortiert nach Stärke. Klick öffnet den Chart. |
| Fear & Greed | Eigener Bereich, mit „Eigenes Fenster“ als separates Pop-up (Adresse `/fear-greed`). |
| News | Schlagzeilen aus RSS-Feeds (BTC-ECHO, BitcoinBlog.de, Cointelegraph, CoinDesk, Bitcoin.com), filterbar auf den gewählten Markt. |
| Signal-Logbuch | Jedes Signal mit Ergebnis (TP1, TP2, Stop-Loss, offen) und Trefferquote. |
| Assistent | Mikrofon-Knopf unten rechts: sprechen, der Bot antwortet mit Stimme. |

## Die 10 Kriterien

| Kriterium | Bullisch, wenn … | Bärisch, wenn … |
|---|---|---|
| Engulfing | grüne Kerze den Körper der roten Vorkerze komplett umschließt | rote Kerze die grüne Vorkerze umschließt |
| Fibonacci-Retracement | Kurs im letzten Aufwärtsimpuls an 0.382 bis 0.786 (am stärksten 0.5 bis 0.618) mit Reaktionskerze dreht | gleiches Muster im Abwärtsimpuls |
| Volumenprofil | Abpraller an VAL oder POC, Ausbruch über VAH | Abweisung an VAH oder POC, Rutsch unter VAL |
| Volumen | Volumen ≥ 1,5× Schnitt bei Aufwärtskerze | … bei Abwärtskerze |
| Support & Widerstand | Abpraller an Unterstützung, Ausbruch über Widerstand | Abweisung am Widerstand, Bruch der Unterstützung |
| Trend | Kurs > EMA 50 > EMA 200, EMA 50 steigt, höhere Hochs/Tiefs (2 von 3) | Gegenteil |
| Dreieck | Aufsteigendes Dreieck bricht nach oben aus | Absteigendes Dreieck bricht nach unten |
| Flagge | Bull-Flagge: steiler Anstieg, Konsolidierung, Ausbruch | Bear-Flagge |
| Cup & Handle | Ausbruch über den Tassenrand | – |
| Kopf-Schulter | Inverse SKS: Ausbruch über die Nackenlinie | SKS: Bruch der Nackenlinie |

Ein **Signal** entsteht, wenn mindestens 3 Kriterien in dieselbe Richtung zeigen, ihr gewichteter Score den der Gegenseite um mindestens 4 übertrifft und eins davon auf der letzten geschlossenen Kerze ausgelöst hat. Alles einstellbar in `config.yaml`.

---

## Online stellen: Schritt für Schritt

Du brauchst einen kleinen Server (VPS) und eine Domain. Normales Webspace-Hosting (nur PHP/HTML) reicht **nicht**, weil der Scanner dauerhaft im Hintergrund laufen muss.

Mach die Schritte einzeln nacheinander. Bei jedem Schritt steht, woran du erkennst, dass er geklappt hat.

### Schritt 1: Code in dein privates GitHub-Repository

Lade den Ordner `signal-desk` in ein **privates** Repository hoch (wie bei deinem bisherigen Scanner). Die Datei `.env` gehört nicht hinein.

*Geklappt, wenn:* du im Repository die Ordner `app`, `deploy` und die Datei `docker-compose.yml` siehst.

### Schritt 2: Server mieten

Bei einem Anbieter wie Hetzner, Netcup oder IONOS einen Cloud-Server mit **Ubuntu 24.04** anlegen. Die kleinste Größe (2 GB RAM) reicht. Notiere die **IP-Adresse**.

*Geklappt, wenn:* der Server im Kundenbereich als „läuft“ angezeigt wird.

### Schritt 3: Domain auf den Server zeigen lassen

In der DNS-Verwaltung deiner Domain einen **A-Eintrag** anlegen, z. B. `signale` → IP deines Servers. Daraus wird `signale.deine-domain.de`.

*Geklappt, wenn:* nach einigen Minuten bis Stunden ein Ping auf die Adresse die Server-IP zeigt.

### Schritt 4: Auf dem Server anmelden und Docker installieren

Über die Web-Konsole deines Anbieters oder per SSH (`ssh root@DEINE-IP`) anmelden, dann:

```bash
curl -fsSL https://get.docker.com | sh
```

*Geklappt, wenn:* `docker --version` eine Versionsnummer ausgibt.

### Schritt 5: Code auf den Server holen

```bash
git clone https://github.com/DEIN-NAME/signal-desk.git
cd signal-desk
```

Bei einem privaten Repository fragt GitHub nach Benutzername und einem **Personal Access Token** (GitHub → Settings → Developer settings → Tokens) statt dem Passwort.

*Geklappt, wenn:* `ls` die Projektdateien zeigt.

### Schritt 6: Einstellungen eintragen

```bash
cp .env.example .env
nano .env
```

Trage mindestens `DOMAIN`, `PUBLIC_URL` und ein eigenes `DASHBOARD_PASSWORD` ein. Speichern mit `Strg+O`, `Enter`, beenden mit `Strg+X`.

### Schritt 7: Starten

```bash
docker compose up -d --build
```

*Geklappt, wenn:* `https://signale.deine-domain.de` im Browser nach Benutzer und Passwort fragt und danach das Dashboard zeigt. Der erste Scan aller Märkte dauert ein bis zwei Minuten.

Fehlersuche: `docker compose logs -f signal-desk` zeigt, was der Bot gerade tut (beenden mit `Strg+C`).

> Alternativ laufen auch Plattformen wie Render oder Railway, die das Docker-Image direkt aus GitHub starten. Wichtig dort: eine Instanz, die nicht einschläft, ein dauerhafter Speicher für `/data` (sonst geht das Logbuch bei Neustarts verloren) und nur **ein** Prozess.

---

## Telegram

Du kannst deinen vorhandenen Bot aus dem BotFather weiterverwenden:

```
TELEGRAM_BOT_TOKEN=123456:ABC...
TELEGRAM_CHAT_ID=@deinKanal      # oder die Zahlen-ID eines Chats/einer Gruppe
```

Der Bot muss im Kanal Admin sein. Danach `docker compose up -d` erneut ausführen.

**Achtung:** Wenn dein alter Scanner über GitHub Actions noch in denselben Kanal postet, kommen Signale doppelt. Schalte dann einen der beiden ab.

In `config.yaml` unter `telegram:` legst du fest, für welche Zeiteinheiten Nachrichten kommen und ob dafür strengere Regeln gelten (`min_factors: 4`).

## Sprachsteuerung

Tippe unten rechts auf den Mikrofon-Knopf und sprich. Beispiele:

- „Zeig mir Solana im 4-Stunden-Chart“
- „Gibt es gerade Signale?“
- „Wie sieht Gold aus?“
- „Wie ist die Stimmung?“ (Fear & Greed)
- „Was gibt es Neues?“
- „Wie ist die Trefferquote?“

„Gesprächsmodus“ lässt das Mikrofon nach jeder Antwort automatisch wieder zuhören. „Antworten vorlesen“ schaltet die Stimme an oder aus.

**Zwei Stufen:**

1. **Ohne Schlüssel** versteht der Bot die festen Befehle oben. Kostenlos.
2. **Mit Claude** (`ANTHROPIC_API_KEY` in der `.env`) antwortet er frei wie ein Gesprächspartner, holt sich dafür die Live-Daten des Bots und öffnet Charts selbst. Den Schlüssel erstellst du in der Claude Console (console.anthropic.com). Jede Frage kostet einen kleinen Betrag; das Modell stellst du in `config.yaml` unter `assistant:` ein.

**Voraussetzungen:** Chrome, Edge oder Safari (Firefox kann keine Spracherkennung), die Seite muss über **HTTPS** laufen (macht Caddy automatisch) und du musst dem Browser den Mikrofonzugriff erlauben. Chrome schickt die Sprachaufnahme zur Erkennung an Google, Safari an Apple.

## Einstellungen (`config.yaml`)

| Eintrag | Bedeutung |
|---|---|
| `exchange` | `binance` (Spot, Standard) oder `bybit` (Perpetuals) als Kursquelle |
| `universe.top_n` | wie viele Kryptos (Top nach Marktkapitalisierung) |
| `universe.extra` / `exclude` | Coins zusätzlich aufnehmen oder ausschließen |
| `timeframes` | `15m`, `1h`, `4h`, `1d` |
| `signal.min_factors` | wie viele Kriterien zusammenpassen müssen |
| `weights` | Gewicht je Kriterium |
| `news.feeds` | eigene RSS-Feeds ergänzen |

Nach einer Änderung: `docker compose restart signal-desk`.

## Wartung

| Aufgabe | Befehl |
|---|---|
| Update nach Code-Änderung | `git pull && docker compose up -d --build` |
| Logs ansehen | `docker compose logs -f signal-desk` |
| Neustart | `docker compose restart signal-desk` |
| Logbuch sichern | Datei `data/signals.db` kopieren |

## Lokal ausprobieren (optional)

Mit Python 3.11+ auf dem eigenen Rechner:

```bash
pip install -r requirements.txt
DEMO_MODE=1 uvicorn app.main:app --port 8000
```

Dann `http://localhost:8000` öffnen. Im Demo-Modus sind alle Kurse und News erfunden. Die Tests der Mustererkennung laufen mit `pip install pytest && python -m pytest`.

## Sicherheit

- Der Bot braucht **keine** Börsen-API-Schlüssel, er liest nur öffentliche Kursdaten.
- Setze immer ein Dashboard-Passwort. Teile die `.env` nie.
- Signale sind regelbasiert und können falsch liegen. Prüfe sie im Logbuch, bevor du echtes Geld einsetzt.

## Datenquellen und Lizenzen

Kurse: Binance bzw. Bybit (öffentliche Marktdaten), Rohstoffe: Yahoo Finance, Top-100-Liste: CoinGecko, Fear & Greed: alternative.me, News: die RSS-Feeds der jeweiligen Seiten. Schrift: TeX Gyre Heros (GUST Font License, liegt in `app/static/fonts`).
