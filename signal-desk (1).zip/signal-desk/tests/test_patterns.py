"""Prüft jedes Kriterium mit einem künstlich gebauten Lehrbuch-Chart.

Start:  python -m pytest -q
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import demo  # noqa: E402
from app.analysis.engine import analyze  # noqa: E402


def finding(res, key):
    return next(f for f in res["findings"] if f["key"] == key)


def check(candles, key, direction, trigger=True):
    res = analyze(candles)
    assert res["ok"], res
    f = finding(res, key)
    assert f["active"], f"{key} nicht aktiv: {f['text']}"
    assert f["direction"] == direction, f"{key}: Richtung {f['direction']} statt {direction} ({f['text']})"
    if trigger:
        assert f["trigger"], f"{key}: kein Trigger ({f['text']})"
    return res, f


def test_inverse_head_shoulders():
    check(demo.inverse_hs(), "head_shoulders", "bull")


def test_head_shoulders():
    check(demo.head_shoulders(), "head_shoulders", "bear")


def test_ascending_triangle():
    check(demo.ascending_triangle(), "triangle", "bull")


def test_descending_triangle():
    check(demo.descending_triangle(), "triangle", "bear")


def test_bull_flag():
    _, f = check(demo.bull_flag(), "flag", "bull")
    assert f["meta"]["volume_drying_up"]


def test_bear_flag():
    check(demo.bear_flag(), "flag", "bear")


def test_cup_handle():
    check(demo.cup_handle(), "cup_handle", "bull")


def test_fibonacci_golden_zone():
    _, f = check(demo.fib_bounce(), "fibonacci", "bull")
    assert "goldenen Zone" in f["text"]


def test_support_bounce_engulfing_volume_signal():
    res = analyze(demo.support_bounce_signal())
    assert finding(res, "engulfing")["direction"] == "bull" and finding(res, "engulfing")["active"]
    assert finding(res, "volume")["direction"] == "bull" and finding(res, "volume")["active"]
    assert finding(res, "trend")["direction"] == "bull"
    assert res["signal"] == "bull", res["bull_factors"]
    plan = res["plan"]
    assert plan["sl"] < plan["entry"] < plan["tp1"] < plan["tp2"]


def test_bearish_engulfing_on_mirrored_data():
    c = demo.support_bounce_signal()
    for k in c:  # Chart spiegeln -> aus bullisch wird bärisch
        o, h, l, cl = k["o"], k["h"], k["l"], k["c"]
        k["o"], k["h"], k["l"], k["c"] = 300 - o, 300 - l, 300 - h, 300 - cl
    res = analyze(c)
    f = finding(res, "engulfing")
    assert f["active"] and f["direction"] == "bear"
    assert res["signal"] == "bear"
    plan = res["plan"]
    assert plan["sl"] > plan["entry"] > plan["tp1"] > plan["tp2"]


def test_random_walk_runs_and_rarely_signals():
    signals = 0
    for seed in range(40):
        res = analyze(demo.random_walk(300, 100, 0.012, seed))
        assert res["ok"]
        assert len(res["findings"]) == 10
        signals += res["signal"] is not None
    assert signals <= 8, f"zu viele Zufallssignale: {signals}/40"


def test_too_few_candles():
    res = analyze(demo.random_walk(30, 100, 0.01, 1))
    assert not res["ok"]
