/* Kerzenchart auf <canvas>, ohne fremde Bibliotheken.
   Zeichnet Kerzen, Volumen, EMA 50/200, Volumenprofil, Fibonacci, Support/Widerstand,
   erkannte Muster, Handelsplan und frühere Signale. Zoom per Mausrad/Buttons, Ziehen verschiebt. */
(function () {
  const C = {
    bull: "#139e9a", bear: "#e2683f", text: "#e8eef4", text2: "#a9b9c9", text3: "#7d95ab",
    grid: "rgba(169,185,201,0.07)", ema50: "#7c78e0", ema200: "#8ca0b3", fib: "#c9d3dd",
    pattern: "#eef3f7", pill: "#1c3349", ink: "#0f2030", panel: "#15293c",
  };
  const FONT = '12px "Heros", "Helvetica Neue", Arial, sans-serif';
  const FONT_B = 'bold 12px "Heros", "Helvetica Neue", Arial, sans-serif';
  const PATTERN_KEYS = ["engulfing", "triangle", "flag", "cup_handle", "head_shoulders"];
  const AXIS_R = 72, AXIS_B = 24, TOP = 10;

  function niceStep(range, target) {
    const raw = range / target;
    const mag = Math.pow(10, Math.floor(Math.log10(raw)));
    const n = raw / mag;
    return (n < 1.5 ? 1 : n < 2.25 ? 2 : n < 3.5 ? 2.5 : n < 7.5 ? 5 : 10) * mag;
  }
  function hexA(hex, a) {
    const n = parseInt(hex.slice(1), 16);
    return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
  }

  class CandleChart {
    constructor(canvas, opts = {}) {
      this.cv = canvas;
      this.ctx = canvas.getContext("2d");
      this.tip = opts.tip;
      this.layers = opts.layers || {};
      this.candles = [];
      this.an = null;
      this.signals = [];
      this.tf = "1h";
      this.key = "";
      this.view = { start: 0, end: 100 };
      this.hover = null;
      this.pointers = new Map();
      this.raf = 0;
      new ResizeObserver(() => this.resize()).observe(canvas.parentElement);
      this.bind();
      this.resize();
    }

    // ------------------------------------------------------------ Daten
    setData({ candles, analysis, signals, tf, key }) {
      const oldN = this.candles.length;
      const atRightEdge = this.view.end >= oldN - 0.5;
      this.candles = candles || [];
      this.an = analysis && analysis.ok ? analysis : null;
      this.signals = signals || [];
      this.tf = tf;
      this.tIndex = new Map(this.candles.map((c, i) => [c.t, i]));
      const n = this.candles.length;
      if (key !== this.key) {
        this.key = key;
        this.resetView();
      } else if (atRightEdge && n !== oldN) {
        const d = n - oldN;
        this.view.start += d;
        this.view.end += d;
      }
      this.requestDraw();
    }
    setLayers(l) { this.layers = l; this.requestDraw(); }
    resetView() {
      const n = this.candles.length;
      const count = Math.min(n + 6, this.w < 520 ? 70 : 130);
      this.view.end = n + 6;
      this.view.start = this.view.end - count;
    }
    idxOfTime(t) {
      if (this.tIndex.has(t)) return this.tIndex.get(t);
      const c = this.candles;
      let lo = 0, hi = c.length - 1;
      if (!c.length) return 0;
      if (t >= c[hi].t) return hi + (t - c[hi].t) / Math.max(1, (c[hi].t - c[Math.max(0, hi - 1)].t) || 1);
      while (lo < hi) { const mid = (lo + hi) >> 1; if (c[mid].t < t) lo = mid + 1; else hi = mid; }
      return lo;
    }

    // ------------------------------------------------------------ Geometrie
    resize() {
      const r = this.cv.parentElement.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      this.w = Math.max(200, r.width);
      this.h = Math.max(200, r.height);
      this.cv.width = Math.round(this.w * dpr);
      this.cv.height = Math.round(this.h * dpr);
      this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      this.requestDraw();
    }
    layout() {
      const plot = { l: 6, r: this.w - AXIS_R, t: TOP, b: this.h - AXIS_B };
      const volH = Math.round((plot.b - plot.t) * 0.15);
      return {
        plot,
        price: { t: plot.t, b: plot.b - volH - 8 },
        vol: { t: plot.b - volH, b: plot.b },
        barW: (plot.r - plot.l) / (this.view.end - this.view.start),
      };
    }
    x(i, L) { return L.plot.l + (i - this.view.start + 0.5) * L.barW; }
    idxAtX(px) {
      const L = this.layout();
      return this.view.start + (px - L.plot.l) / L.barW - 0.5;
    }

    // ------------------------------------------------------------ Interaktion
    zoomAt(idx, factor) {
      const n = this.candles.length;
      const v = this.view;
      let count = (v.end - v.start) * factor;
      count = Math.max(15, Math.min(n + 40, count));
      const frac = (idx - v.start) / (v.end - v.start);
      v.start = idx - frac * count;
      v.end = v.start + count;
      this.clampView();
      this.requestDraw();
    }
    pan(bars) {
      this.view.start += bars;
      this.view.end += bars;
      this.clampView();
      this.requestDraw();
    }
    clampView() {
      const n = this.candles.length, v = this.view, count = v.end - v.start;
      if (v.end > n + 30) { v.end = n + 30; v.start = v.end - count; }
      if (v.start < -10) { v.start = -10; v.end = v.start + count; }
    }
    bind() {
      const cv = this.cv;
      cv.addEventListener("wheel", (e) => {
        e.preventDefault();
        if (Math.abs(e.deltaX) > Math.abs(e.deltaY)) {
          this.pan(e.deltaX / this.layout().barW);
        } else {
          this.zoomAt(this.idxAtX(e.offsetX), Math.exp(e.deltaY * 0.0012));
        }
      }, { passive: false });
      cv.addEventListener("pointerdown", (e) => {
        this.pointers.set(e.pointerId, e.offsetX);
        if (this.pointers.size === 1) {
          cv.setPointerCapture(e.pointerId);
          this.drag = { x: e.offsetX, start: this.view.start, end: this.view.end, moved: false };
        }
      });
      cv.addEventListener("pointermove", (e) => {
        if (this.drag && this.pointers.has(e.pointerId)) {
          const dx = e.offsetX - this.drag.x;
          if (Math.abs(dx) > 3) this.drag.moved = true;
          if (this.drag.moved) {
            const bars = dx / this.layout().barW;
            this.view.start = this.drag.start - bars;
            this.view.end = this.drag.end - bars;
            this.clampView();
          }
        }
        this.hover = { x: e.offsetX, y: e.offsetY };
        this.requestDraw();
      });
      const end = (e) => { this.pointers.delete(e.pointerId); if (!this.pointers.size) this.drag = null; };
      cv.addEventListener("pointerup", end);
      cv.addEventListener("pointercancel", end);
      cv.addEventListener("pointerleave", () => { this.hover = null; this.requestDraw(); });
      cv.addEventListener("dblclick", () => { this.resetView(); this.requestDraw(); });
      cv.addEventListener("keydown", (e) => {
        const count = this.view.end - this.view.start;
        if (e.key === "ArrowLeft") this.pan(-count * 0.1);
        else if (e.key === "ArrowRight") this.pan(count * 0.1);
        else if (e.key === "+" || e.key === "=") this.zoomAt((this.view.start + this.view.end) / 2, 0.8);
        else if (e.key === "-") this.zoomAt((this.view.start + this.view.end) / 2, 1.25);
        else if (e.key === "0") { this.resetView(); this.requestDraw(); }
        else return;
        e.preventDefault();
      });
    }
    zoomButton(dir) { this.zoomAt(this.view.end - 6, dir > 0 ? 0.75 : 1.33); }

    requestDraw() {
      if (this.raf) return;
      this.raf = requestAnimationFrame(() => { this.raf = 0; this.draw(); });
    }

    // ------------------------------------------------------------ Zeichnen
    draw() {
      const g = this.ctx, c = this.candles, n = c.length;
      g.clearRect(0, 0, this.w, this.h);
      if (!n) return;
      const L = this.layout();
      const i0 = Math.max(0, Math.floor(this.view.start));
      const i1 = Math.min(n - 1, Math.ceil(this.view.end));
      if (i1 < i0) return;
      let lo = Infinity, hi = -Infinity, vmax = 0;
      for (let i = i0; i <= i1; i++) {
        lo = Math.min(lo, c[i].l); hi = Math.max(hi, c[i].h); vmax = Math.max(vmax, c[i].v);
      }
      const plan = this.an && this.an.plan;
      if (plan && this.layers.plan) {
        const span = hi - lo;
        for (const p of [plan.entry, plan.sl, plan.tp1]) {
          if (p > lo - span * 0.6 && p < hi + span * 0.6) { lo = Math.min(lo, p); hi = Math.max(hi, p); }
        }
      }
      const pad = (hi - lo) * 0.07 || hi * 0.01;
      lo -= pad; hi += pad;
      this.scale = { lo, hi };
      const y = (p) => L.price.b - ((p - lo) / (hi - lo)) * (L.price.b - L.price.t);
      this.y = y;
      const ref = c[n - 1].c;

      g.save();
      g.beginPath();
      g.rect(L.plot.l, L.plot.t - 4, L.plot.r - L.plot.l, L.plot.b - L.plot.t + 4);
      g.clip();

      // Raster
      const step = niceStep(hi - lo, Math.max(3, Math.round((L.price.b - L.price.t) / 70)));
      g.strokeStyle = C.grid; g.lineWidth = 1;
      const priceTicks = [];
      for (let p = Math.ceil(lo / step) * step; p <= hi; p += step) {
        const yy = Math.round(y(p)) + 0.5;
        if (yy < L.price.t || yy > L.price.b) continue;
        priceTicks.push([p, yy]);
        g.beginPath(); g.moveTo(L.plot.l, yy); g.lineTo(L.plot.r, yy); g.stroke();
      }
      const timeTicks = this.timeTicks(L, i0, i1);
      for (const [xx] of timeTicks) {
        g.beginPath(); g.moveTo(Math.round(xx) + 0.5, L.plot.t); g.lineTo(Math.round(xx) + 0.5, L.plot.b); g.stroke();
      }

      // Volumenprofil
      const prof = this.an && this.an.profile;
      if (prof && this.layers.vp) this.drawProfile(g, L, y, prof);

      // Overlays aus den Kriterien
      const labels = [];
      this._tags = [];
      if (this.an) this.drawFindings(g, L, y, labels);

      // EMAs
      if (this.an) {
        if (this.layers.ema50) this.drawSeries(g, L, this.an.ema50, C.ema50, i0, i1);
        if (this.layers.ema200) this.drawSeries(g, L, this.an.ema200, C.ema200, i0, i1);
      }

      // Volumen + Kerzen
      const bw = Math.max(1, Math.min(L.barW * 0.7, 24));
      for (let i = i0; i <= i1; i++) {
        const k = c[i], up = k.c >= k.o, col = up ? C.bull : C.bear;
        const xx = this.x(i, L);
        const vh = vmax ? (k.v / vmax) * (L.vol.b - L.vol.t) : 0;
        g.fillStyle = hexA(col, k.live ? 0.18 : 0.38);
        g.fillRect(xx - bw / 2, L.vol.b - vh, bw, vh);
        g.globalAlpha = k.live ? 0.55 : 1;
        g.strokeStyle = col; g.fillStyle = col;
        const wx = Math.round(xx) + 0.5;
        g.beginPath(); g.moveTo(wx, y(k.h)); g.lineTo(wx, y(k.l)); g.stroke();
        const yt = y(Math.max(k.o, k.c)), yb = y(Math.min(k.o, k.c));
        g.fillRect(xx - bw / 2, yt, bw, Math.max(1, yb - yt));
        g.globalAlpha = 1;
      }

      // Handelsplan + frühere Signale
      if (this.layers.plan) this.drawPlan(g, L, y, labels);
      g.restore();

      // Beschriftungen rechts im Chart (ohne Überlappung)
      this.drawLabels(g, L, labels);

      // Achsen
      g.font = FONT; g.fillStyle = C.text3; g.textBaseline = "middle"; g.textAlign = "left";
      for (const [p, yy] of priceTicks) g.fillText(F.price(p, ref), L.plot.r + 8, yy);
      g.textAlign = "center"; g.textBaseline = "top";
      for (const [xx, txt] of timeTicks) g.fillText(txt, xx, L.plot.b + 7);

      // aktueller Kurs
      const last = c[n - 1];
      const ly = y(last.c);
      if (ly > L.price.t && ly < L.price.b) {
        g.setLineDash([2, 3]); g.strokeStyle = hexA(last.c >= last.o ? C.bull : C.bear, 0.7);
        g.beginPath(); g.moveTo(L.plot.l, Math.round(ly) + 0.5); g.lineTo(L.plot.r, Math.round(ly) + 0.5); g.stroke();
        g.setLineDash([]);
        this.axisTag(g, L, ly, F.price(last.c, ref), last.c >= last.o ? C.bull : C.bear, C.ink);
      }

      this.drawCrosshair(g, L, y, ref);
    }

    timeTicks(L, i0, i1) {
      const c = this.candles, out = [];
      const every = Math.max(1, Math.ceil(90 / L.barW));
      const intraday = this.tf !== "1d";
      let lastDay = null;
      for (let i = i0; i <= i1; i++) {
        if (i % every) continue;
        const d = new Date(c[i].t * 1000);
        const day = d.toDateString();
        let txt;
        if (!intraday) txt = F.when(c[i].t, "day");
        else if (day !== lastDay) txt = F.when(c[i].t, "day");
        else txt = F.when(c[i].t, "time");
        lastDay = day;
        out.push([this.x(i, L), txt]);
      }
      return out;
    }

    drawSeries(g, L, arr, color, i0, i1) {
      if (!arr || !arr.length) return;
      g.strokeStyle = color; g.lineWidth = 1.75; g.lineJoin = "round";
      g.beginPath();
      let started = false;
      for (let i = Math.max(i0, 0); i <= Math.min(i1, arr.length - 1); i++) {
        const v = arr[i];
        if (v === null || v === undefined) continue;
        const xx = this.x(i, L), yy = this.y(v);
        if (!started) { g.moveTo(xx, yy); started = true; } else g.lineTo(xx, yy);
      }
      g.stroke();
      g.lineWidth = 1;
    }

    drawProfile(g, L, y, prof) {
      const maxV = Math.max(...prof.bins.map((b) => b.vol)) || 1;
      const maxW = (L.plot.r - L.plot.l) * 0.2;
      for (const b of prof.bins) {
        const y1 = y(b.to), y2 = y(b.from);
        if (y2 < L.price.t || y1 > L.price.b) continue;
        const w = (b.vol / maxV) * maxW;
        const mid = (b.from + b.to) / 2;
        const inVA = mid >= prof.val && mid <= prof.vah;
        const isPoc = prof.poc >= b.from && prof.poc <= b.to;
        g.fillStyle = isPoc ? "rgba(232,238,244,0.34)" : inVA ? "rgba(169,185,201,0.19)" : "rgba(169,185,201,0.10)";
        g.fillRect(L.plot.r - w, y1 + 0.5, w, Math.max(1, y2 - y1 - 1));
      }
    }

    hline(g, L, y, price, color, dash, fromIdx, width = 1) {
      const yy = Math.round(y(price)) + 0.5;
      if (yy < L.price.t - 2 || yy > L.price.b + 2) return null;
      const x0 = fromIdx !== undefined ? Math.max(L.plot.l, this.x(fromIdx, L)) : L.plot.l;
      g.strokeStyle = color; g.lineWidth = width; g.setLineDash(dash || []);
      g.beginPath(); g.moveTo(x0, yy); g.lineTo(L.plot.r, yy); g.stroke();
      g.setLineDash([]); g.lineWidth = 1;
      return yy;
    }

    drawFindings(g, L, y, labels) {
      const ref = this.candles[this.candles.length - 1].c;
      for (const f of this.an.findings) {
        if (!f.drawings || !f.drawings.length || f.state === "none") continue;
        const layer = f.key === "fibonacci" ? "fib" : f.key === "support_resistance" ? "sr"
          : f.key === "volume_profile" ? "vp" : PATTERN_KEYS.includes(f.key) ? "patterns" : null;
        if (!layer || !this.layers[layer]) continue;
        for (const d of f.drawings) {
          if (d.type === "zone") {
            const ya = y(d.from), yb = y(d.to);
            const x0 = d.from_t ? Math.max(L.plot.l, this.x(this.idxOfTime(d.from_t), L)) : L.plot.l;
            g.fillStyle = "rgba(201,211,221,0.07)";
            g.fillRect(x0, Math.min(ya, yb), L.plot.r - x0, Math.abs(yb - ya));
          } else if (d.type === "hline") {
            const st = d.style;
            const color = st === "fib" ? hexA(C.fib, 0.55) : st === "support" ? hexA(C.bull, 0.75)
              : st === "resistance" ? hexA(C.bear, 0.75) : st === "poc" ? "rgba(232,238,244,0.55)" : "rgba(169,185,201,0.4)";
            const dash = st === "fib" ? [2, 3] : st === "va" ? [1, 3] : st === "poc" ? [] : [6, 4];
            const fromIdx = d.from_t ? this.idxOfTime(d.from_t) : undefined;
            const yy = this.hline(g, L, y, d.price, color, dash, fromIdx);
            if (yy !== null) {
              const mark = st === "support" ? C.bull : st === "resistance" ? C.bear : st === "fib" ? C.fib : C.text3;
              labels.push({ y: yy, text: `${d.label}  ${F.price(d.price, ref)}`, mark });
            }
          } else if (d.type === "line") {
            const pts = d.points.map(([t, p]) => [this.x(this.idxOfTime(t), L), y(p)]);
            const isNeck = d.style === "neckline";
            g.strokeStyle = isNeck ? "rgba(238,243,247,0.8)" : "rgba(238,243,247,0.88)";
            g.lineWidth = isNeck ? 1.25 : 1.75; g.setLineDash(isNeck ? [5, 4] : []);
            g.beginPath();
            pts.forEach(([xx, yy], k) => (k ? g.lineTo(xx, yy) : g.moveTo(xx, yy)));
            g.stroke(); g.setLineDash([]); g.lineWidth = 1;
            if (d.label) this.tag(g, pts[0][0], pts[0][1] - 12, d.label, d.dir === "bear" ? C.bear : C.bull);
          } else if (d.type === "curve") {
            const [p0, b, p2] = d.points.map(([t, p]) => [this.x(this.idxOfTime(t), L), y(p)]);
            const cx = 2 * b[0] - (p0[0] + p2[0]) / 2, cy = 2 * b[1] - (p0[1] + p2[1]) / 2;
            g.strokeStyle = "rgba(238,243,247,0.88)"; g.lineWidth = 1.75;
            g.beginPath(); g.moveTo(p0[0], p0[1]); g.quadraticCurveTo(cx, cy, p2[0], p2[1]); g.stroke();
            g.lineWidth = 1;
            if (d.label) this.tag(g, p0[0], p0[1] - 14, d.label, C.bull);
          } else if (d.type === "marker") {
            const i = this.idxOfTime(d.t), xx = this.x(i, L);
            const up = d.dir === "bull";
            const k = this.candles[Math.round(i)];
            if (!k) continue;
            const yy = up ? y(k.l) + 8 : y(k.h) - 8;
            g.fillStyle = up ? C.bull : C.bear;
            g.beginPath();
            if (up) { g.moveTo(xx, yy); g.lineTo(xx - 6, yy + 9); g.lineTo(xx + 6, yy + 9); }
            else { g.moveTo(xx, yy); g.lineTo(xx - 6, yy - 9); g.lineTo(xx + 6, yy - 9); }
            g.closePath(); g.fill();
            g.font = FONT; g.fillStyle = C.text2; g.textAlign = "center";
            g.textBaseline = up ? "top" : "bottom";
            g.fillText(d.label, xx, up ? yy + 12 : yy - 12);
          }
        }
      }
    }

    drawPlan(g, L, y, labels) {
      const plan = this.an && this.an.plan;
      const ref = this.candles[this.candles.length - 1].c;
      const lastClosed = this.candles.filter((k) => !k.live).length - 1;
      if (plan) {
        const rows = [
          ["Einstieg", plan.entry, C.text2, []],
          ["Stop-Loss", plan.sl, C.bear, [4, 3]],
          ["TP1", plan.tp1, C.bull, [4, 3]],
          ["TP2", plan.tp2, C.bull, [4, 3]],
        ];
        for (const [name, p, col, dash] of rows) {
          const yy = this.hline(g, L, y, p, col, dash, lastClosed - 2, 1.25);
          if (yy !== null) labels.push({ y: yy, text: `${name}  ${F.price(p, ref)}`, mark: col, strong: true });
        }
      }
      for (const s of this.signals) {
        const i = this.idxOfTime(s.candle_time);
        if (i < this.view.start - 1 || i > this.view.end + 1) continue;
        const k = this.candles[Math.round(i)];
        if (!k) continue;
        const up = s.direction === "bull", xx = this.x(i, L);
        const yy = up ? y(k.l) + 26 : y(k.h) - 26;
        g.fillStyle = C.panel; g.strokeStyle = up ? C.bull : C.bear; g.lineWidth = 1.5;
        g.beginPath(); g.arc(xx, yy, 8, 0, Math.PI * 2); g.fill(); g.stroke(); g.lineWidth = 1;
        g.fillStyle = C.text; g.font = FONT_B; g.textAlign = "center"; g.textBaseline = "middle";
        g.fillText(up ? "L" : "S", xx, yy + 0.5);
      }
    }

    tag(g, x, y, text, mark) {
      g.font = FONT;
      const w = g.measureText(text).width + 18;
      const x0 = Math.min(Math.max(x - 4, 8), this.w - AXIS_R - w - 4);
      // nicht über ein anderes Muster-Etikett legen
      for (let k = 0; k < 6 && this._tags.some((r) => x0 < r.x + r.w && r.x < x0 + w && Math.abs(r.y - y) < 20); k++) y -= 21;
      this._tags.push({ x: x0, y, w });
      g.fillStyle = "rgba(28,51,73,0.92)";
      g.beginPath(); g.roundRect(x0, y - 9, w, 18, 4); g.fill();
      g.fillStyle = mark; g.fillRect(x0 + 6, y - 3, 6, 6);
      g.fillStyle = C.text; g.textAlign = "left"; g.textBaseline = "middle";
      g.fillText(text, x0 + 15, y + 0.5);
    }

    drawLabels(g, L, labels) {
      if (!labels.length) return;
      labels.sort((a, b) => a.y - b.y);
      const gap = 17;
      for (let k = 1; k < labels.length; k++) {
        if (labels[k].y - labels[k - 1].y < gap) labels[k].y = labels[k - 1].y + gap;
      }
      const bottom = L.price.b - 4;
      if (labels[labels.length - 1].y > bottom) {
        labels[labels.length - 1].y = bottom;
        for (let k = labels.length - 2; k >= 0; k--) labels[k].y = Math.min(labels[k].y, labels[k + 1].y - gap);
      }
      g.font = FONT;
      for (const lb of labels) {
        const w = g.measureText(lb.text).width + 20;
        const x0 = L.plot.r - w - 6;
        g.fillStyle = lb.strong ? "rgba(28,51,73,0.96)" : "rgba(21,41,60,0.9)";
        g.beginPath(); g.roundRect(x0, lb.y - 8.5, w, 17, 4); g.fill();
        g.fillStyle = lb.mark; g.fillRect(x0 + 6, lb.y - 3, 7, 6);
        g.fillStyle = lb.strong ? C.text : C.text2; g.textAlign = "left"; g.textBaseline = "middle";
        g.fillText(lb.text, x0 + 16, lb.y + 0.5);
      }
    }

    axisTag(g, L, yy, text, fill, ink) {
      g.font = FONT_B;
      const w = AXIS_R - 6;
      g.fillStyle = fill;
      g.beginPath(); g.roundRect(L.plot.r + 2, yy - 9, w, 18, 3); g.fill();
      g.fillStyle = ink; g.textAlign = "left"; g.textBaseline = "middle";
      g.fillText(text, L.plot.r + 7, yy + 0.5);
    }

    drawCrosshair(g, L, y, ref) {
      const h = this.hover, c = this.candles;
      if (!h || h.x > L.plot.r || h.y > L.plot.b || h.x < L.plot.l) { if (this.tip) this.tip.hidden = true; return; }
      const i = Math.round(this.idxAtX(h.x));
      if (i < 0 || i >= c.length) { if (this.tip) this.tip.hidden = true; return; }
      const xx = Math.round(this.x(i, L)) + 0.5;
      g.strokeStyle = "rgba(232,238,244,0.35)"; g.setLineDash([3, 3]);
      g.beginPath(); g.moveTo(xx, L.plot.t); g.lineTo(xx, L.plot.b); g.stroke();
      if (h.y >= L.price.t && h.y <= L.price.b) {
        g.beginPath(); g.moveTo(L.plot.l, Math.round(h.y) + 0.5); g.lineTo(L.plot.r, Math.round(h.y) + 0.5); g.stroke();
        const p = this.scale.lo + ((L.price.b - h.y) / (L.price.b - L.price.t)) * (this.scale.hi - this.scale.lo);
        g.setLineDash([]);
        this.axisTag(g, L, h.y, F.price(p, ref), C.pill, C.text);
      }
      g.setLineDash([]);
      const k = c[i], prev = c[i - 1];
      if (this.tip) {
        const chg = prev ? (k.c / prev.c - 1) * 100 : null;
        this.tip.hidden = false;
        this.tip.innerHTML =
          `<b>${F.when(k.t, this.tf === "1d" ? "date" : "full")}</b>${k.live ? " (läuft)" : ""}&nbsp;&nbsp; ` +
          `E <b>${F.price(k.o, ref)}</b> H <b>${F.price(k.h, ref)}</b> T <b>${F.price(k.l, ref)}</b> S <b>${F.price(k.c, ref)}</b>` +
          (chg !== null ? ` &nbsp;<b>${F.pct(chg, 2)}</b>` : "") + ` &nbsp;Vol <b>${F.compact(k.v)}</b>`;
      }
    }
  }

  window.CandleChart = CandleChart;
})();
