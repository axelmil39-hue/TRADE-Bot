/* Deutsche Zahlen- und Zeitformate, gemeinsam für alle Seiten. */
(function () {
  const nf = {};
  function num(x, d = 1) {
    if (x === null || x === undefined || !isFinite(x)) return "–";
    const k = "d" + d;
    nf[k] = nf[k] || new Intl.NumberFormat("de-DE", { minimumFractionDigits: d, maximumFractionDigits: d });
    return nf[k].format(x);
  }
  function decimalsFor(p) {
    const a = Math.abs(p);
    if (a >= 10000) return 0;
    if (a >= 1000) return 1;
    if (a >= 100) return 2;
    if (a >= 1) return 3;
    if (a >= 0.01) return 4;
    return 8;
  }
  function price(p, ref) {
    if (p === null || p === undefined || !isFinite(p)) return "–";
    return num(p, decimalsFor(ref ?? p));
  }
  function pct(x, d = 1) {
    if (x === null || x === undefined || !isFinite(x)) return "–";
    return (x > 0 ? "+" : x < 0 ? "−" : "") + num(Math.abs(x), d) + " %";
  }
  function compact(x) {
    if (!isFinite(x)) return "–";
    const a = Math.abs(x);
    if (a >= 1e9) return num(x / 1e9, 1) + " Mrd.";
    if (a >= 1e6) return num(x / 1e6, 1) + " Mio.";
    if (a >= 1e3) return num(x / 1e3, 1) + " Tsd.";
    return num(x, 0);
  }
  const dtf = {
    time: new Intl.DateTimeFormat("de-DE", { hour: "2-digit", minute: "2-digit" }),
    day: new Intl.DateTimeFormat("de-DE", { day: "numeric", month: "short" }),
    dayTime: new Intl.DateTimeFormat("de-DE", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }),
    full: new Intl.DateTimeFormat("de-DE", { weekday: "short", day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }),
    date: new Intl.DateTimeFormat("de-DE", { weekday: "short", day: "numeric", month: "short", year: "numeric" }),
  };
  function when(t, style = "dayTime") { return dtf[style].format(new Date(t * 1000)); }
  function ago(t) {
    const s = Math.max(0, Date.now() / 1000 - t);
    if (s < 90) return "gerade eben";
    if (s < 3600) return "vor " + Math.round(s / 60) + " Min.";
    if (s < 86400) return "vor " + Math.round(s / 3600) + " Std.";
    const d = Math.round(s / 86400);
    return d === 1 ? "gestern" : "vor " + d + " Tagen";
  }
  const TF = { "15m": "15 Min", "1h": "1 Std", "4h": "4 Std", "1d": "1 Tag" };
  window.F = { num, price, pct, compact, when, ago, decimalsFor, TF };
})();
