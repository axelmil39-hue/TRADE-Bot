/* Signal-Desk Dashboard: lädt Daten von der API und verbindet alle Bereiche. */
(function () {
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const TF_SEC = { "15m": 900, "1h": 3600, "4h": 14400, "1d": 86400 };
  const TREND = { up: ["aufwärts", "up"], down: ["abwärts", "down"], side: ["seitwärts", ""] };
  const LAYERS = [
    ["ema50", "EMA 50", "#7c78e0", true],
    ["ema200", "EMA 200", "#8ca0b3", true],
    ["patterns", "Muster", "#eef3f7", true],
    ["sr", "Support & Widerstand", "#139e9a", true],
    ["fib", "Fibonacci", "#c9d3dd", false],
    ["vp", "Volumenprofil", "#a9b9c9", true],
    ["plan", "Handelsplan & Signale", "#e2683f", true],
  ];

  const S = {
    meta: null, symbol: null, tf: null, chart: null, overview: null, signals: null,
    scanKind: "all", scanTf: "all", search: "", sort: { key: "score", dir: -1 }, limit: 60,
    newsMode: "all",
  };

  async function api(path, opts) {
    const r = await fetch(path, opts);
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw Object.assign(new Error(data.error || "HTTP " + r.status), { status: r.status, data });
    return data;
  }
  const visible = () => document.visibilityState === "visible";
  function every(ms, fn) { setInterval(() => { if (visible()) fn(); }, ms); }

  // ------------------------------------------------------------------ Ebenen
  function loadLayers() {
    const def = Object.fromEntries(LAYERS.map(([k, , , on]) => [k, on]));
    try { return Object.assign(def, JSON.parse(localStorage.getItem("sd-layers") || "{}")); } catch (e) { return def; }
  }
  const layers = loadLayers();
  function renderLayerChips() {
    $("layers").innerHTML = LAYERS.map(([k, label, color]) =>
      `<button type="button" class="chip" data-k="${k}" aria-pressed="${layers[k]}" style="--c:${color}"><span class="sw" style="background:${color}"></span>${label}</button>`).join("");
    $("layers").onclick = (e) => {
      const b = e.target.closest("button"); if (!b) return;
      layers[b.dataset.k] = !layers[b.dataset.k];
      b.setAttribute("aria-pressed", layers[b.dataset.k]);
      try { localStorage.setItem("sd-layers", JSON.stringify(layers)); } catch (er) { /* egal */ }
      chart.setLayers(layers);
    };
  }

  const chart = new CandleChart($("chart"), { tip: $("chart-tip"), layers });
  $("zoom-in").onclick = () => chart.zoomButton(1);
  $("zoom-out").onclick = () => chart.zoomButton(-1);

  // ------------------------------------------------------------------ Markt wählen
  function marketBy(sym) { return (S.meta?.markets || []).find((m) => m.symbol === sym); }
  function renderMarketList() {
    $("market-list").innerHTML = (S.meta?.markets || []).map((m) => `<option value="${esc(m.name)} (${esc(m.symbol)})"></option>`).join("");
  }
  $("market-input").addEventListener("change", (e) => {
    const v = e.target.value.trim();
    const m = v.match(/\(([^)]+)\)\s*$/);
    let sym = m ? m[1] : null;
    if (!sym) {
      const q = v.toLowerCase();
      const hit = (S.meta?.markets || []).find((x) => [x.name, x.base, x.symbol].some((s) => (s || "").toLowerCase() === q))
        || (S.meta?.markets || []).find((x) => x.name.toLowerCase().includes(q));
      sym = hit && hit.symbol;
    }
    if (sym) { select(sym, S.tf); e.target.value = ""; e.target.blur(); }
  });

  function renderTfSwitch() {
    const tfs = S.meta.timeframes;
    $("tf-switch").innerHTML = tfs.map((t) => `<button type="button" data-tf="${t}" aria-pressed="${t === S.tf}">${F.TF[t]}</button>`).join("");
    $("tf-switch").onclick = (e) => { const b = e.target.closest("button"); if (b) select(S.symbol, b.dataset.tf); };
    $("scan-tf").innerHTML = [["all", "Alle TF"], ...tfs.map((t) => [t, F.TF[t]])]
      .map(([v, l]) => `<button type="button" data-v="${v}" aria-pressed="${v === S.scanTf}">${l}</button>`).join("");
  }

  function select(symbol, tf, opts = {}) {
    if (!symbol) return;
    S.symbol = symbol;
    S.tf = tf || S.tf;
    history.replaceState(null, "", `?symbol=${encodeURIComponent(symbol)}&tf=${S.tf}`);
    for (const b of $("tf-switch").querySelectorAll("button")) b.setAttribute("aria-pressed", b.dataset.tf === S.tf);
    loadChart(true);
    renderScanner();
    if (S.newsMode === "market") loadNews();
    updateNewsButton();
    if (opts.scroll) document.querySelector(".desk").scrollIntoView({ behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
  }

  // ------------------------------------------------------------------ Chart + Urteil
  let chartReq = 0;
  async function loadChart(fresh) {
    const id = ++chartReq;
    if (fresh) $("chart-msg").textContent = "Lädt Kerzen …";
    try {
      const d = await api(`/api/chart?symbol=${encodeURIComponent(S.symbol)}&tf=${S.tf}`);
      if (id !== chartReq) return;
      S.chart = d;
      $("chart-msg").textContent = d.analysis && !d.analysis.ok ? d.analysis.error : "";
      chart.setData({ candles: d.candles, analysis: d.analysis, signals: d.signals, tf: d.tf, key: d.market.symbol + d.tf });
      renderHead(d);
      renderVerdict(d.analysis);
    } catch (e) {
      if (id !== chartReq) return;
      $("chart-msg").textContent = e.status === 404 ? "Markt nicht gefunden." : "Kerzen konnten nicht geladen werden: " + e.message;
    }
  }

  function renderHead(d) {
    const m = d.market, c = d.candles, last = c[c.length - 1];
    $("inst-name").textContent = m.name;
    $("inst-sym").textContent = `${m.symbol}, ${m.kind === "commodity" ? "Rohstoff-Future" : "Krypto"}, ${F.TF[d.tf]}`;
    $("inst-price").textContent = F.price(last.c);
    const k = Math.max(1, Math.round(86400 / TF_SEC[d.tf]));
    const ref = c.length > k ? c[c.length - 1 - k].c : c[0].c;
    const chg = (last.c / ref - 1) * 100;
    $("inst-chg").innerHTML = `<span class="tri ${chg >= 0 ? "up" : "down"}"></span>${F.pct(chg, 2)} in 24 h`;
    const closed = c.filter((x) => !x.live);
    $("chart-time").textContent = closed.length ? `Letzte geschlossene Kerze: ${F.when(closed[closed.length - 1].t, "full")}` : "";
    document.title = `${m.name} ${F.price(last.c)} | Signal-Desk`;
  }

  function stateWord(f) {
    if (f.active) return f.direction === "bull" ? "Bullisch" : f.direction === "bear" ? "Bärisch" : "Aktiv";
    if (f.state === "forming") return f.direction === "bear" ? "Bärisch in Formation" : "Bullisch in Formation";
    if (f.state === "info") return "Info";
    return "Nicht erkannt";
  }

  function renderVerdict(a) {
    const minF = S.meta.min_factors, minS = S.meta.min_score;
    if (!a || !a.ok) {
      $("v-title").textContent = "Keine Analyse";
      $("v-sub").textContent = a ? a.error : "";
      $("criteria").innerHTML = "";
      $("plan").hidden = $("plan-note").hidden = true;
      return;
    }
    const bull = a.bull_factors.length, bear = a.bear_factors.length;
    const title = a.signal === "bull" ? "Long-Signal" : a.signal === "bear" ? "Short-Signal" : "Kein Signal";
    $("v-title").textContent = title;
    let sub;
    if (a.signal) {
      const n = a.signal === "bull" ? bull : bear;
      sub = `${n} Faktoren ${a.signal === "bull" ? "bullisch" : "bärisch"}, Score ${F.num(Math.abs(a.net_score))}. Ausgelöst auf der letzten Kerze.`;
    } else {
      const lead = Math.max(bull, bear);
      const dir = bull >= bear ? "bullisch" : "bärisch";
      const trig = a.findings.some((f) => f.active && f.trigger && f.direction === (bull >= bear ? "bull" : "bear"));
      if (lead < minF) sub = `Noch ${minF - lead} Faktor${minF - lead > 1 ? "en" : ""} bis zum Signal (${lead} ${dir}, nötig ${minF}).`;
      else if (bull === bear) sub = "Bullische und bärische Faktoren halten sich die Waage.";
      else if (Math.abs(a.net_score) < minS) sub = `Score-Vorsprung ${F.num(Math.abs(a.net_score))} ist kleiner als ${F.num(minS)}.`;
      else if (!trig) sub = "Genug Faktoren, aber kein Auslöser auf der letzten Kerze.";
      else sub = "Bedingungen knapp verfehlt.";
    }
    $("v-sub").textContent = sub;

    const fBull = a.findings.filter((f) => !f.active && f.state === "forming" && f.direction === "bull").length;
    const fBear = a.findings.filter((f) => !f.active && f.state === "forming" && f.direction === "bear").length;
    const cells = Array(10).fill("");
    for (let k = 0; k < Math.min(10, bull); k++) cells[k] = "bull";
    for (let k = bull; k < Math.min(10, bull + fBull); k++) cells[k] = "forming-bull";
    for (let k = 0; k < Math.min(10 - bull - fBull, bear); k++) cells[9 - k] = "bear";
    for (let k = bear; k < Math.min(10 - bull - fBull, bear + fBear); k++) if (!cells[9 - k]) cells[9 - k] = "forming-bear";
    const markAt = (k) => `left:calc(${k} * (100% - 27px) / 10 + ${k - 0.5} * 3px - 1px)`;
    $("tug").innerHTML = cells.map((c) => `<span class="tug-cell ${c}"></span>`).join("")
      + `<span class="tug-mark" style="${markAt(minF)}"></span><span class="tug-mark" style="${markAt(10 - minF)}"></span>`;
    $("tug-bull").textContent = bull;
    $("tug-bear").textContent = bear;
    $("tug-need").textContent = `Signal ab ${minF}`;

    const p = a.plan;
    if (p) {
      const ref = p.entry;
      $("plan").innerHTML = `
        <div><dt><span class="dot" style="background:#a9b9c9"></span>Einstieg</dt><dd>${F.price(p.entry, ref)}</dd></div>
        <div><dt><span class="dot" style="background:var(--bear)"></span>Stop-Loss (${F.num(p.risk_pct, 1)} %)</dt><dd>${F.price(p.sl, ref)}</dd></div>
        <div><dt><span class="dot" style="background:var(--bull)"></span>TP1</dt><dd>${F.price(p.tp1, ref)}</dd></div>
        <div><dt><span class="dot" style="background:var(--bull)"></span>TP2 (CRV ${F.num(p.crv_tp2, 1)})</dt><dd>${F.price(p.tp2, ref)}</dd></div>`;
      $("plan").hidden = false;
      $("plan-note").textContent = "Vorschlag aus Kerzenstruktur, ATR und Musterziel. Keine Anlageberatung.";
      $("plan-note").hidden = false;
    } else {
      $("plan").hidden = $("plan-note").hidden = true;
    }

    $("criteria").innerHTML = a.findings.map((f) => {
      const cls = f.active ? f.direction : f.state === "forming" ? "forming" : f.state;
      return `<li class="${cls}">
        <span class="bar"></span>
        <span class="name">${esc(f.label)}${f.trigger ? '<span class="tag">Auslöser</span>' : ""}</span>
        <span class="state">${stateWord(f)}</span>
        <span class="txt">${esc(f.text)}</span>
      </li>`;
    }).join("");
  }

  // ------------------------------------------------------------------ Scanner
  function miniTug(r) {
    const b = (r.bull_factors || []).length, s = (r.bear_factors || []).length;
    const cells = Array(10).fill("");
    for (let k = 0; k < Math.min(10, b); k++) cells[k] = "bull";
    for (let k = 0; k < Math.min(10 - b, s); k++) cells[9 - k] = "bear";
    return `<span class="minitug" title="${b} bullisch, ${s} bärisch">${cells.map((c) => `<i class="${c}"></i>`).join("")}</span>`;
  }

  function renderScanner() {
    const ov = S.overview;
    if (!ov) return;
    let rows = ov.rows.filter((r) => !r.error);
    if (S.scanKind === "signal") rows = rows.filter((r) => r.signal);
    else if (S.scanKind !== "all") rows = rows.filter((r) => r.kind === S.scanKind);
    if (S.scanTf !== "all") rows = rows.filter((r) => r.tf === S.scanTf);
    if (S.search) {
      const q = S.search.toLowerCase();
      rows = rows.filter((r) => (r.name + " " + r.symbol).toLowerCase().includes(q));
    }
    const { key, dir } = S.sort;
    const val = (r) => key === "score" ? (r.signal ? 1000 : 0) + Math.abs(r.net_score || 0)
      : key === "name" ? r.name.toLowerCase() : r[key] ?? -Infinity;
    rows.sort((a, b) => { const x = val(a), y = val(b); return (x > y ? 1 : x < y ? -1 : 0) * dir; });
    const total = rows.length;
    rows = rows.slice(0, S.limit);
    $("scan-body").innerHTML = rows.map((r) => {
      const tr = TREND[r.trend] || ["–", ""];
      const cur = r.symbol === S.symbol && r.tf === S.tf ? "current" : "";
      const sig = r.signal === "bull" ? '<span class="sig bull">Long</span>' : r.signal === "bear" ? '<span class="sig bear">Short</span>' : '<span class="sig none">–</span>';
      return `<tr class="${cur}" data-s="${esc(r.symbol)}" data-tf="${r.tf}" tabindex="0">
        <td><span class="mname">${esc(r.name)}</span><span class="msym">${esc(r.base || r.symbol)}</span></td>
        <td>${F.TF[r.tf]}</td>
        <td class="num">${F.price(r.price)}</td>
        <td class="num">${F.pct(r.change_24h, 1)}</td>
        <td class="hide-sm">${tr[1] ? `<span class="tri ${tr[1]}"></span> ` : ""}${tr[0]}</td>
        <td>${miniTug(r)}</td>
        <td class="num">${r.net_score > 0 ? "+" : r.net_score < 0 ? "−" : ""}${F.num(Math.abs(r.net_score || 0))}</td>
        <td>${sig}</td>
      </tr>`;
    }).join("") || `<tr><td colspan="8" class="small">Keine Treffer für diesen Filter.</td></tr>`;
    $("scan-more").hidden = total <= S.limit;
    const nSig = ov.rows.filter((r) => r.signal).length;
    $("scan-count").textContent = `${ov.status.markets} Märkte, ${nSig} aktive Signal${nSig === 1 ? "" : "e"}`;
  }
  $("scan-body").addEventListener("click", (e) => {
    const tr = e.target.closest("tr[data-s]"); if (tr) select(tr.dataset.s, tr.dataset.tf, { scroll: true });
  });
  $("scan-body").addEventListener("keydown", (e) => {
    const tr = e.target.closest("tr[data-s]"); if (tr && e.key === "Enter") select(tr.dataset.s, tr.dataset.tf, { scroll: true });
  });
  $("scan-search").addEventListener("input", (e) => { S.search = e.target.value; renderScanner(); });
  function segHandler(id, prop) {
    $(id).addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      S[prop] = b.dataset.v;
      for (const x of $(id).querySelectorAll("button")) x.setAttribute("aria-pressed", x === b);
      renderScanner();
    });
  }
  segHandler("scan-kind", "scanKind");
  segHandler("scan-tf", "scanTf");
  $("scan-more").onclick = () => { S.limit += 60; renderScanner(); };
  document.querySelectorAll("th button[data-sort]").forEach((b) => b.addEventListener("click", () => {
    const k = b.dataset.sort;
    S.sort = { key: k, dir: S.sort.key === k ? -S.sort.dir : (k === "name" ? 1 : -1) };
    document.querySelectorAll("th button[data-sort]").forEach((x) => x.removeAttribute("aria-sort"));
    b.setAttribute("aria-sort", S.sort.dir > 0 ? "ascending" : "descending");
    renderScanner();
  }));

  function renderStatus() {
    const st = S.overview.status;
    const el = $("scan-status");
    let cls = "", txt;
    if (st.scanning && !st.last_scan_at) { cls = "busy"; txt = `Erster Scan läuft (${st.markets} Märkte)`; }
    else if (st.scanning) { cls = "busy"; txt = "Scannt gerade"; }
    else if (st.last_scan_at) txt = `Letzter Scan ${F.ago(st.last_scan_at)}, ${st.markets} Märkte`;
    else txt = "Scanner startet";
    if (st.errors && st.errors.length && st.errors[st.errors.length - 1].t > st.now - 600) {
      cls = "err"; txt += `, ${st.errors.length} Abruffehler`;
      el.title = st.errors.map((e) => e.msg).join("\n");
    } else el.title = "";
    el.innerHTML = `<span class="pulse ${cls}"></span><span>${esc(txt)}</span>`;
  }

  async function loadOverview() {
    try {
      S.overview = await api("/api/overview");
      renderScanner();
      renderStatus();
    } catch (e) { /* nächster Versuch beim nächsten Intervall */ }
  }

  // ------------------------------------------------------------------ Logbuch
  async function loadSignals() {
    try {
      const d = await api("/api/signals?limit=60");
      const s = d.stats;
      $("log-stats").innerHTML = `
        <div><b>${s.win_rate === null ? "–" : F.num(s.win_rate, 1) + " %"}</b>Trefferquote</div>
        <div><b>${s.decided}</b>abgeschlossen</div>
        <div><b>${s.tp2}</b>TP2 erreicht</div>
        <div><b>${s.tp1}</b>TP1 erreicht</div>
        <div><b>${s.sl}</b>Stop-Loss</div>
        <div><b>${s.open}</b>offen</div>`;
      $("log-body").innerHTML = d.signals.map((r) => {
        const win = r.status === "tp1" || r.status === "tp2", loss = r.status === "sl";
        const ref = r.entry;
        return `<tr data-s="${esc(r.symbol)}" data-tf="${r.timeframe}" tabindex="0">
          <td>${F.when(r.candle_time)}</td>
          <td><span class="mname">${esc(r.name)}</span></td>
          <td>${F.TF[r.timeframe] || r.timeframe}</td>
          <td><span class="sig ${r.direction}">${r.direction === "bull" ? "Long" : "Short"}</span></td>
          <td class="num">${F.price(r.entry, ref)}</td>
          <td class="num">${F.price(r.sl, ref)}</td>
          <td class="num">${F.price(r.tp1, ref)}</td>
          <td class="num">${F.price(r.tp2, ref)}</td>
          <td><span class="status-chip ${win ? "win" : loss ? "loss" : ""}">${esc(r.status_de)}${r.status === "open" && r.tp1_hit ? ", TP1 ✓" : ""}</span></td>
        </tr>`;
      }).join("") || `<tr><td colspan="9" class="small">Noch keine Signale. Sobald der Scanner eins findet, steht es hier.</td></tr>`;
    } catch (e) { /* egal */ }
  }
  $("log-body").addEventListener("click", (e) => {
    const tr = e.target.closest("tr[data-s]"); if (tr) select(tr.dataset.s, tr.dataset.tf, { scroll: true });
  });

  // ------------------------------------------------------------------ News
  function updateNewsButton() {
    const m = marketBy(S.symbol);
    $("news-market-btn").textContent = m ? `Zu ${m.name}` : "Zum Markt";
  }
  async function loadNews() {
    let q = "";
    if (S.newsMode === "market") {
      const m = marketBy(S.symbol);
      if (m) q = [m.name, m.base].filter((x) => x && x.length > 1 && !x.includes("=")).join(",");
    }
    try {
      const d = await api("/api/news" + (q ? "?q=" + encodeURIComponent(q) : ""));
      $("news-list").innerHTML = d.items.slice(0, 40).map((n) => `
        <li>
          <div class="meta">${esc(n.source)}${n.published ? ", " + F.ago(n.published) : ""}</div>
          <a href="${esc(n.url)}" target="_blank" rel="noopener noreferrer">${esc(n.title)}</a>
        </li>`).join("") || `<li class="small">${S.newsMode === "market" ? "Keine aktuellen Meldungen zu diesem Markt." : "Noch keine Meldungen geladen."}</li>`;
      $("news-note").textContent = d.errors && d.errors.length ? `Nicht erreichbar: ${d.errors.map((e) => e.split(":")[0]).join(", ")}` : "";
    } catch (e) {
      $("news-note").textContent = "News konnten nicht geladen werden.";
    }
  }
  $("news-filter").addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    S.newsMode = b.dataset.v;
    for (const x of $("news-filter").querySelectorAll("button")) x.setAttribute("aria-pressed", x === b);
    loadNews();
  });

  // ------------------------------------------------------------------ Fear & Greed
  async function loadFng() {
    try { FNG.render($("fng-root"), await api("/api/feargreed"), { days: 30 }); }
    catch (e) { FNG.render($("fng-root"), null); }
  }
  $("fng-popout").onclick = () => {
    const w = window.open("/fear-greed", "fearGreed", "width=440,height=700,menubar=no,toolbar=no,location=no");
    if (!w) location.href = "/fear-greed";
  };

  // ------------------------------------------------------------------ Assistent
  const voice = new Voice({
    getContext: () => ({ symbol: S.symbol, tf: S.tf }),
    onAction: (a) => {
      const go = (id) => document.getElementById(id).scrollIntoView({ behavior: "smooth", block: "start" });
      if (a.type === "show_chart") select(a.symbol, a.tf, { scroll: true });
      else if (a.type === "show_fng") go("fng");
      else if (a.type === "show_news") go("news");
      else if (a.type === "show_log") go("log");
    },
  });

  // ------------------------------------------------------------------ Start
  async function init() {
    renderLayerChips();
    try {
      S.meta = await api("/api/meta");
    } catch (e) {
      $("chart-msg").textContent = "Server nicht erreichbar.";
      setTimeout(init, 4000);
      return;
    }
    $("demo-banner").hidden = !S.meta.demo;
    voice.setMode(S.meta.assistant);
    const p = new URLSearchParams(location.search);
    S.tf = S.meta.timeframes.includes(p.get("tf")) ? p.get("tf") : (p.get("tf") in TF_SEC ? p.get("tf") : S.meta.timeframes[0]);
    renderTfSwitch();
    renderMarketList();
    let sym = p.get("symbol");
    if (!sym || (!marketBy(sym) && S.meta.markets.length)) {
      sym = (marketBy("BTCUSDT") || S.meta.markets[0] || {}).symbol;
    }
    if (!sym) {
      $("chart-msg").textContent = "Marktliste wird geladen …";
      setTimeout(init, 3000);
      return;
    }
    select(sym, S.tf);
    loadOverview();
    loadSignals();
    loadNews();
    loadFng();
    every(30000, () => { loadOverview(); loadChart(false); });
    every(60000, loadSignals);
    every(300000, loadNews);
    every(600000, loadFng);
    every(120000, async () => { try { S.meta = await api("/api/meta"); renderMarketList(); } catch (e) { /* egal */ } });
    document.addEventListener("visibilitychange", () => { if (visible()) { loadOverview(); loadChart(false); } });
  }
  init();
})();
