/* Sprachassistent im Browser.
   Spracherkennung: Web Speech API (Chrome, Edge, Safari; braucht HTTPS oder localhost).
   Sprachausgabe: speechSynthesis mit deutscher Stimme.
   Gesprächsmodus: nach jeder Antwort hört das Mikrofon automatisch wieder zu. */
(function () {
  const $ = (id) => document.getElementById(id);
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

  class Voice {
    constructor({ onAction, getContext }) {
      this.onAction = onAction;
      this.getContext = getContext;
      this.history = [];
      this.listening = false;
      this.busy = false;
      this.panel = $("assistant");
      this.log = $("as-log");
      this.input = $("as-text");
      this.mic = $("as-mic");
      this.fab = $("voice-fab");
      this.speakBox = $("as-speak");
      this.convoBox = $("as-convo");
      this.voice = null;
      this.restore();
      this.pickVoice();
      if ("speechSynthesis" in window) speechSynthesis.onvoiceschanged = () => this.pickVoice();
      this.bind();
      this.greeted = false;
    }

    restore() {
      try {
        const s = JSON.parse(localStorage.getItem("sd-voice") || "{}");
        if (typeof s.speak === "boolean") this.speakBox.checked = s.speak;
        if (typeof s.convo === "boolean") this.convoBox.checked = s.convo;
      } catch (e) { /* Speicher nicht verfügbar */ }
    }
    persist() {
      try { localStorage.setItem("sd-voice", JSON.stringify({ speak: this.speakBox.checked, convo: this.convoBox.checked })); } catch (e) { /* egal */ }
    }

    pickVoice() {
      if (!("speechSynthesis" in window)) return;
      const de = speechSynthesis.getVoices().filter((v) => v.lang && v.lang.toLowerCase().startsWith("de"));
      const rank = (v) => (/natural|neural|online/i.test(v.name) ? 0 : /google/i.test(v.name) ? 1 : /anna|petra|helena|katja|marlene|vicki/i.test(v.name) ? 2 : 3);
      this.voice = de.sort((a, b) => rank(a) - rank(b))[0] || null;
    }

    bind() {
      this.fab.addEventListener("click", () => {
        if (this.panel.hidden) { this.open(); if (SR) this.start(); }
        else if (this.listening) this.stop();
        else if (SR) this.start();
      });
      $("as-close").addEventListener("click", () => this.close());
      this.mic.addEventListener("click", () => (this.listening ? this.stop() : this.start()));
      $("as-form").addEventListener("submit", (e) => {
        e.preventDefault();
        const t = this.input.value.trim();
        if (t) { this.unlockSpeech(); this.send(t); }
      });
      this.input.addEventListener("keydown", (e) => {
        if (this.listening && e.key.length === 1) this.abort();  // wer tippt, will nicht sprechen
      });
      this.speakBox.addEventListener("change", () => { if (!this.speakBox.checked && "speechSynthesis" in window) speechSynthesis.cancel(); this.persist(); });
      this.convoBox.addEventListener("change", () => this.persist());
      document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !this.panel.hidden) this.close(); });
    }

    open() {
      this.panel.hidden = false;
      this.fab.setAttribute("aria-expanded", "true");
      if (!this.greeted) {
        this.greeted = true;
        this.addMsg("hint", SR
          ? "Tippe auf das Mikrofon und sprich, z. B. „Zeig mir Solana im 4-Stunden-Chart“, „Gibt es Signale?“ oder „Wie ist die Stimmung?“"
          : "Dein Browser unterstützt keine Spracherkennung. Nutze Chrome, Edge oder Safari, oder tippe deine Frage.");
      }
      if (!SR) this.input.focus();
    }
    close() {
      this.abort();
      if ("speechSynthesis" in window) speechSynthesis.cancel();
      this.panel.hidden = true;
      this.fab.setAttribute("aria-expanded", "false");
    }

    setMode(mode) {
      $("as-mode").textContent = mode === "claude" ? "Antworten von Claude" : "Feste Sprachbefehle";
    }

    unlockSpeech() {
      // iOS erlaubt Sprachausgabe erst nach einer Nutzeraktion
      if ("speechSynthesis" in window && !this.unlocked) {
        try { speechSynthesis.speak(new SpeechSynthesisUtterance("")); } catch (e) { /* egal */ }
        this.unlocked = true;
      }
    }

    start() {
      if (!SR || this.listening) return;
      this.unlockSpeech();
      if ("speechSynthesis" in window) speechSynthesis.cancel();
      const rec = new SR();
      rec.lang = "de-DE";
      rec.interimResults = true;
      rec.continuous = false;
      rec.maxAlternatives = 1;
      let finalText = "";
      rec.onresult = (e) => {
        let interim = "";
        for (let k = e.resultIndex; k < e.results.length; k++) {
          const r = e.results[k];
          if (r.isFinal) finalText += r[0].transcript;
          else interim += r[0].transcript;
        }
        this.input.value = (finalText + " " + interim).trim();
      };
      rec.onerror = (e) => {
        if (e.error === "not-allowed" || e.error === "service-not-allowed") {
          this.addMsg("hint", "Mikrofon ist blockiert. Erlaube den Zugriff in den Browser-Einstellungen für diese Seite (nur über HTTPS möglich).");
        } else if (e.error === "no-speech") {
          this.addMsg("hint", "Ich habe nichts gehört. Tippe nochmal auf das Mikrofon.");
        } else if (e.error !== "aborted") {
          this.addMsg("hint", "Spracherkennung fehlgeschlagen (" + e.error + ").");
        }
      };
      rec.onend = () => {
        this.setListening(false);
        if (this.discard) { this.discard = false; return; }
        const t = (finalText || this.input.value).trim();
        if (t) this.send(t);
      };
      this.rec = rec;
      try {
        rec.start();
        this.setListening(true);
      } catch (e) {
        this.setListening(false);
      }
    }
    abort() {
      if (this.rec && this.listening) {
        this.discard = true;
        this.input.value = "";
        try { this.rec.abort(); } catch (e) { /* egal */ }
      }
    }
    stop() {
      if (this.rec && this.listening) { try { this.rec.stop(); } catch (e) { /* egal */ } }
    }
    setListening(on) {
      this.listening = on;
      this.mic.classList.toggle("listening", on);
      this.fab.classList.toggle("listening", on);
      this.mic.setAttribute("aria-label", on ? "Zuhören beenden" : "Spracheingabe starten");
      this.input.placeholder = on ? "Ich höre zu …" : "Frag etwas oder tippe auf das Mikrofon";
    }

    addMsg(kind, text) {
      const d = document.createElement("div");
      d.className = "msg " + kind;
      d.textContent = text;
      this.log.appendChild(d);
      this.log.scrollTop = this.log.scrollHeight;
      return d;
    }

    async send(text) {
      if (this.busy) return;
      this.busy = true;
      this.input.value = "";
      this.addMsg("user", text);
      const pending = this.addMsg("bot", "…");
      try {
        const r = await fetch("/api/assistant", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ message: text, history: this.history.slice(-10), context: this.getContext() }),
        });
        const data = await r.json();
        if (!r.ok) throw new Error(data.error || r.status);
        pending.textContent = data.reply;
        this.setMode(data.mode);
        this.history.push({ role: "user", content: text }, { role: "assistant", content: data.reply });
        for (const a of data.actions || []) this.onAction(a);
        this.say(data.reply);
      } catch (e) {
        pending.textContent = "Der Assistent ist gerade nicht erreichbar. Prüfe die Verbindung zum Server.";
      } finally {
        this.busy = false;
      }
    }

    say(text) {
      const again = () => { if (this.convoBox.checked && !this.panel.hidden && SR) setTimeout(() => this.start(), 250); };
      if (!this.speakBox.checked || !("speechSynthesis" in window)) { again(); return; }
      speechSynthesis.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = "de-DE";
      if (this.voice) u.voice = this.voice;
      u.rate = 1.05;
      u.onend = again;
      u.onerror = again;
      speechSynthesis.speak(u);
    }
  }

  window.Voice = Voice;
})();
