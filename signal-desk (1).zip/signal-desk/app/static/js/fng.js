/* Fear & Greed: Halbkreis-Anzeige + Verlauf. Wird im Dashboard und im eigenen Fenster genutzt. */
(function () {
  const ZONES = [
    { to: 24, color: "#e2683f", label: "Extreme Angst" },
    { to: 44, color: "#b27358", label: "Angst" },
    { to: 55, color: "#5d7186", label: "Neutral" },
    { to: 74, color: "#4e9693", label: "Gier" },
    { to: 100, color: "#139e9a", label: "Extreme Gier" },
  ];
  const NS = "http://www.w3.org/2000/svg";
  const zoneOf = (v) => ZONES.find((z) => v <= z.to) || ZONES[4];

  function polar(cx, cy, r, v) {
    const a = Math.PI * (1 - v / 100);
    return [cx + r * Math.cos(a), cy - r * Math.sin(a)];
  }
  function arc(cx, cy, r, v0, v1) {
    const [x0, y0] = polar(cx, cy, r, v0), [x1, y1] = polar(cx, cy, r, v1);
    return `M${x0.toFixed(2)},${y0.toFixed(2)} A${r},${r} 0 0 1 ${x1.toFixed(2)},${y1.toFixed(2)}`;
  }

  function gaugeSVG(value) {
    const cx = 120, cy = 118, r = 96;
    let from = 0, segs = "";
    for (const z of ZONES) {
      segs += `<path d="${arc(cx, cy, r, from + 0.8, z.to - 0.8)}" stroke="${z.color}" stroke-width="16" fill="none" stroke-linecap="butt"/>`;
      from = z.to;
    }
    const ticks = [0, 25, 50, 75, 100].map((t) => {
      const [x, y] = polar(cx, cy, r + 18, t);
      return `<text x="${x.toFixed(1)}" y="${(y + 4).toFixed(1)}" font-size="11" text-anchor="middle">${t}</text>`;
    }).join("");
    const [nx, ny] = polar(cx, cy, r - 24, value);
    return `<svg class="fng-gauge" viewBox="-16 0 272 132" role="img" aria-label="Fear and Greed ${value} von 100">
      ${segs}${ticks}
      <line x1="${cx}" y1="${cy}" x2="${nx.toFixed(1)}" y2="${ny.toFixed(1)}" stroke="#e8eef4" stroke-width="3" stroke-linecap="round"/>
      <circle cx="${cx}" cy="${cy}" r="6" fill="#e8eef4"/>
    </svg>`;
  }

  function historyChart(host, hist) {
    host.innerHTML = "";
    if (!hist || hist.length < 2) return;
    const W = Math.max(200, host.clientWidth), H = host.clientHeight || 130;
    const padL = 24, padR = 4, padT = 8, padB = 18;
    const x = (k) => padL + (k / (hist.length - 1)) * (W - padL - padR);
    const y = (v) => padT + (1 - v / 100) * (H - padT - padB);
    const svg = document.createElementNS(NS, "svg");
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", `Verlauf der letzten ${hist.length} Tage`);
    let from = 0, body = "";
    for (const z of ZONES) {
      body += `<rect x="${padL}" y="${y(z.to)}" width="${W - padL - padR}" height="${y(from) - y(z.to)}" fill="${z.color}" opacity="0.09"/>`;
      from = z.to;
    }
    for (const t of [25, 50, 75]) {
      body += `<text x="${padL - 6}" y="${y(t) + 4}" font-size="10" text-anchor="end" fill="#7d95ab">${t}</text>`;
    }
    const d = hist.map((p, k) => `${k ? "L" : "M"}${x(k).toFixed(1)},${y(p.v).toFixed(1)}`).join("");
    body += `<path d="${d}" fill="none" stroke="#e8eef4" stroke-width="2" stroke-linejoin="round"/>`;
    body += `<text x="${padL}" y="${H - 4}" font-size="10" fill="#7d95ab">${F.when(hist[0].t, "day")}</text>`;
    body += `<text x="${W - padR}" y="${H - 4}" font-size="10" text-anchor="end" fill="#7d95ab">${F.when(hist[hist.length - 1].t, "day")}</text>`;
    body += `<line id="fx" y1="${padT}" y2="${H - padB}" stroke="#a9b9c9" stroke-dasharray="3 3" visibility="hidden"/>`;
    body += `<circle id="fd" r="4.5" fill="#e8eef4" stroke="#15293c" stroke-width="2" visibility="hidden"/>`;
    body += `<rect x="${padL}" y="0" width="${W - padL - padR}" height="${H}" fill="transparent" id="fhit"/>`;
    svg.innerHTML = body;
    host.appendChild(svg);
    const tip = document.createElement("div");
    tip.className = "fng-tip";
    tip.hidden = true;
    host.appendChild(tip);
    const line = svg.querySelector("#fx"), dot = svg.querySelector("#fd");
    const move = (ev) => {
      const r = svg.getBoundingClientRect();
      const px = ((ev.clientX - r.left) / r.width) * W;
      const k = Math.max(0, Math.min(hist.length - 1, Math.round(((px - padL) / (W - padL - padR)) * (hist.length - 1))));
      const p = hist[k];
      line.setAttribute("x1", x(k)); line.setAttribute("x2", x(k)); line.setAttribute("visibility", "visible");
      dot.setAttribute("cx", x(k)); dot.setAttribute("cy", y(p.v)); dot.setAttribute("visibility", "visible");
      tip.hidden = false;
      tip.style.left = (x(k) / W) * 100 + "%";
      tip.style.top = "-22px";
      tip.textContent = `${F.when(p.t, "date")}: ${p.v} ${zoneOf(p.v).label}`;
    };
    const leave = () => { tip.hidden = true; line.setAttribute("visibility", "hidden"); dot.setAttribute("visibility", "hidden"); };
    svg.addEventListener("pointermove", move);
    svg.addEventListener("pointerleave", leave);
  }

  function render(root, data, opts = {}) {
    if (!data || data.error) {
      root.innerHTML = `<p class="small">Fear &amp; Greed ist gerade nicht verfügbar. Die Seite versucht es automatisch erneut.</p>`;
      return;
    }
    const h = data.history || [];
    const back = (days) => (h.length > days ? h[h.length - 1 - days].v : null);
    const cmp = [["Gestern", back(1)], ["Vor 7 Tagen", back(7)], ["Vor 30 Tagen", back(30)]]
      .filter(([, v]) => v !== null)
      .map(([l, v]) => `<div><b>${v}</b>${l}</div>`).join("");
    const days = opts.days || 30;
    root.innerHTML = `
      <div class="fng-body">
        ${gaugeSVG(data.value)}
        <div class="fng-value">${data.value}</div>
        <div class="fng-label">${data.label}</div>
        <div class="fng-compare">${cmp}</div>
        <div class="fng-hist"></div>
        <p class="small" style="margin:8px 0 0;align-self:flex-start">Krypto-Stimmungsindex von ${data.source}, täglich aktualisiert. Hier: letzte ${Math.min(days, h.length)} Tage.</p>
      </div>`;
    const host = root.querySelector(".fng-hist");
    const draw = () => historyChart(host, h.slice(-days));
    draw();
    if (!root._ro) {
      root._ro = new ResizeObserver(() => { const hh = root.querySelector(".fng-hist"); if (hh) historyChart(hh, (root._data.history || []).slice(-(root._days || 30))); });
      root._ro.observe(root);
    }
    root._data = data;
    root._days = days;
  }

  window.FNG = { render, zoneOf };
})();
