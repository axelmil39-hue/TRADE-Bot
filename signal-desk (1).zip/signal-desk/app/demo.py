"""Demo-Daten: künstliche Kerzen mit eingebauten Chartmustern.

Wird genutzt für
  * den Demo-Modus (DEMO_MODE=1), damit man das Dashboard ohne Internet sieht,
  * die automatischen Tests der Mustererkennung.
Alles hier ist erfunden und wird im Dashboard deutlich als Demo markiert.
"""
from __future__ import annotations

import time
import zlib

import numpy as np


def build(points, noise=0.15, wick=0.3, seed=0, vol=100.0, vol_noise=0.25, tf_sec=3600, end_t=None, vol_points=None):
    """points: [(bar_index, close), ...] -> Kerzenliste (stückweise linearer Verlauf + Rauschen)."""
    rng = np.random.default_rng(seed)
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    n = xs[-1] + 1
    closes = np.interp(np.arange(n), xs, ys) + rng.normal(0, noise, n)
    for x, y in points:  # Stützpunkte exakt treffen
        closes[x] = y
    if vol_points:
        vxs = [p[0] for p in vol_points]
        vys = [p[1] for p in vol_points]
        vols = np.interp(np.arange(n), vxs, vys)
    else:
        vols = np.full(n, vol)
    vols = vols * np.exp(rng.normal(0, vol_noise, n))
    end_t = end_t or (int(time.time()) // tf_sec) * tf_sec - tf_sec
    t0 = end_t - (n - 1) * tf_sec
    out = []
    prev = closes[0]
    for k in range(n):
        o, c = prev, closes[k]
        w1, w2 = abs(rng.normal(wick, wick / 3)), abs(rng.normal(wick, wick / 3))
        out.append({"t": t0 + k * tf_sec, "o": float(o), "h": float(max(o, c) + w1),
                    "l": float(min(o, c) - w2), "c": float(c), "v": float(vols[k])})
        prev = c
    return out


def add(candles, o, h, l, c, v=None, tf_sec=None):
    """Hängt eine handgebaute Kerze an."""
    tf_sec = tf_sec or (candles[-1]["t"] - candles[-2]["t"])
    v = v if v is not None else candles[-1]["v"]
    candles.append({"t": candles[-1]["t"] + tf_sec, "o": o, "h": h, "l": l, "c": c, "v": v})
    return candles


def scale(candles, factor):
    for k in candles:
        for f in ("o", "h", "l", "c"):
            k[f] *= factor
    return candles


def shift_time(candles, tf_sec):
    """Zeitachse so verschieben, dass die letzte Kerze gerade geschlossen ist."""
    end_t = (int(time.time()) // tf_sec) * tf_sec - tf_sec
    off = end_t - candles[-1]["t"]
    for k in candles:
        k["t"] += off
    return candles


# ---------------------------------------------------------------------------
# Musterbausteine (Länge ~100 Kerzen); vorne wird mit Zufallsweg aufgefüllt
# ---------------------------------------------------------------------------
def pad_front(points, total=300, seed=0, drift_to=None):
    """Verlängert ein Muster nach vorne, damit EMA 200 sinnvoll ist."""
    rng = np.random.default_rng(seed + 99)
    first_x, first_y = points[0]
    lead = total - (points[-1][0] + 1)
    if lead <= 0:
        return points
    start = drift_to if drift_to is not None else first_y * (1 + rng.uniform(-0.08, 0.08))
    pts = [(0, start)]
    k = 10
    while k < lead:
        frac = k / lead
        pts.append((k, start + (first_y - start) * frac + rng.normal(0, abs(first_y) * 0.01)))
        k += 10
    return pts + [(x + lead, y) for x, y in points]


def inverse_hs(seed=1):
    pts = [(0, 130), (60, 100), (70, 92), (82, 104), (95, 85), (108, 104), (120, 92), (132, 103.5)]
    c = build(pad_front(pts, 300, seed, drift_to=140), seed=seed,
              vol_points=[(0, 100), (299, 100)])
    add(c, 103.5, 106.6, 103.2, 106.3, v=c[-1]["v"] * 2.4)
    return c


def head_shoulders(seed=2):
    pts = [(0, 70), (60, 100), (70, 108), (82, 96), (95, 115), (108, 96), (120, 108), (132, 96.5)]
    c = build(pad_front(pts, 300, seed, drift_to=60), seed=seed)
    add(c, 96.5, 96.8, 93.4, 93.7, v=c[-1]["v"] * 2.0)
    return c


def ascending_triangle(seed=3):
    pts = [(0, 90), (30, 100), (40, 110), (50, 100), (60, 110), (70, 104), (80, 110), (88, 107), (94, 109.5)]
    c = build(pad_front(pts, 300, seed, drift_to=80), seed=seed)
    add(c, 109.5, 112.0, 109.2, 111.7, v=c[-1]["v"] * 2.2)
    return c


def descending_triangle(seed=4):
    pts = [(0, 120), (30, 110), (40, 100), (50, 110), (60, 100), (70, 106), (80, 100), (88, 103), (94, 100.5)]
    c = build(pad_front(pts, 300, seed, drift_to=130), seed=seed)
    add(c, 100.5, 100.8, 98.0, 98.3, v=c[-1]["v"] * 2.2)
    return c


def _flag_volume(c):
    for k in c[-20:-11]:   # Fahnenmast: hohes Volumen
        k["v"] = 300.0
    for k in c[-11:]:      # Flagge: Volumen trocknet aus
        k["v"] = 70.0


def bull_flag(seed=5):
    pts = [(0, 100), (40, 100), (48, 120), (51, 118), (53, 119), (56, 116.5), (58, 117.5), (59, 116.2)]
    c = build(pad_front(pts, 300, seed, drift_to=92), seed=seed, noise=0.1)
    _flag_volume(c)
    add(c, 116.2, 121.0, 116.0, 120.7, v=260.0)
    return c


def bear_flag(seed=6):
    pts = [(0, 120), (40, 120), (48, 100), (51, 102), (53, 101), (56, 103.5), (58, 102.5), (59, 103.8)]
    c = build(pad_front(pts, 300, seed, drift_to=128), seed=seed, noise=0.1)
    _flag_volume(c)
    add(c, 103.8, 104.0, 99.0, 99.3, v=260.0)
    return c


def cup_handle(seed=7):
    pts = [(0, 80), (20, 100), (30, 88), (40, 82), (50, 80), (60, 82), (70, 88), (80, 99.5),
           (86, 96), (90, 98.5)]
    c = build(pad_front(pts, 300, seed, drift_to=70), seed=seed, noise=0.1)
    add(c, 98.5, 101.4, 98.3, 101.1, v=c[-1]["v"] * 2.0)
    return c


def fib_bounce(seed=8):
    pts = [(0, 100), (20, 100), (40, 150), (52, 123.5)]
    c = build(pad_front(pts, 300, seed, drift_to=95), seed=seed)
    add(c, 123.5, 125.4, 121.5, 125.1)
    return c


def support_bounce_signal(seed=9):
    """Aufwärtstrend, Rücksetzer an Unterstützung, bullisches Engulfing mit Volumen."""
    pts = [(0, 60), (150, 90), (165, 100), (175, 94), (190, 106), (200, 100), (215, 112), (228, 106.2), (230, 105.6)]
    c = build(pad_front(pts, 300, seed, drift_to=55), seed=seed, noise=0.1)
    add(c, 105.6, 105.8, 104.9, 105.0)
    add(c, 105.0, 107.4, 104.8, 107.2, v=c[-1]["v"] * 2.6)
    return c


def random_walk(n=300, start=100.0, vol=0.012, seed=0, tf_sec=3600, drift=0.0):
    rng = np.random.default_rng(seed)
    rets = rng.normal(drift, vol, n)
    closes = start * np.exp(np.cumsum(rets))
    pts = [(k, float(closes[k])) for k in range(n)]
    return build(pts, noise=0, wick=start * vol * 0.6, seed=seed, tf_sec=tf_sec)


DEMO_MARKETS = [
    # (Symbol, Name, Typ, Generator, Preisfaktor)
    ("BTCUSDT", "Bitcoin", "crypto", inverse_hs, 1000.0),
    ("ETHUSDT", "Ethereum", "crypto", support_bounce_signal, 35.0),
    ("SOLUSDT", "Solana", "crypto", bull_flag, 1.6),
    ("XRPUSDT", "XRP", "crypto", ascending_triangle, 0.022),
    ("BNBUSDT", "BNB", "crypto", head_shoulders, 7.0),
    ("DOGEUSDT", "Dogecoin", "crypto", descending_triangle, 0.0019),
    ("ADAUSDT", "Cardano", "crypto", bear_flag, 0.0065),
    ("LINKUSDT", "Chainlink", "crypto", cup_handle, 0.19),
    ("AVAXUSDT", "Avalanche", "crypto", fib_bounce, 0.22),
    ("GC=F", "Gold", "commodity", lambda seed=11: random_walk(300, 100, 0.004, seed), 26.0),
    ("SI=F", "Silber", "commodity", lambda seed=12: random_walk(300, 100, 0.008, seed), 0.32),
    ("CL=F", "Rohöl (WTI)", "commodity", lambda seed=13: random_walk(300, 100, 0.009, seed), 0.68),
    ("NG=F", "Erdgas", "commodity", lambda seed=14: random_walk(300, 100, 0.02, seed), 0.034),
]


def demo_candles(symbol: str, tf: str) -> list[dict]:
    tf_sec = {"15m": 900, "1h": 3600, "4h": 14400, "1d": 86400}.get(tf, 3600)
    for sym, _name, _typ, gen, factor in DEMO_MARKETS:
        if sym == symbol:
            if tf == "1h":
                c = gen()
            else:  # andere Zeiteinheiten: eigener Zufallsweg
                c = random_walk(300, 100, 0.012 * (tf_sec / 3600) ** 0.5,
                                seed=zlib.crc32(f"{sym}{tf}".encode()) % 1000, tf_sec=tf_sec)
            c = scale(c, factor)
            c = shift_time(c, tf_sec)
            # letzte Kerze als "laufende" Kerze zusätzlich anhängen
            last = c[-1]
            c.append({"t": last["t"] + tf_sec, "o": last["c"], "h": last["c"] * 1.002,
                      "l": last["c"] * 0.999, "c": last["c"] * 1.001, "v": last["v"] * 0.3, "live": True})
            return c
    return []
