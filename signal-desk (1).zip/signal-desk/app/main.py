"""Signal-Desk Webserver: Dashboard + API.

Start lokal:   uvicorn app.main:app --port 8000
Demo ohne Internet:  DEMO_MODE=1 uvicorn app.main:app --port 8000
"""
from __future__ import annotations

import asyncio
import base64
import contextlib
import logging
import math
import secrets
import time

from starlette.applications import Starlette
from starlette.middleware import Middleware
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.gzip import GZipMiddleware
from starlette.requests import Request
from starlette.responses import FileResponse, JSONResponse, Response
from starlette.routing import Mount, Route
from starlette.staticfiles import StaticFiles

from . import config
from .analysis.patterns import LABELS, ORDER
from .assistant import Assistant
from .markets import TF_LABEL, TF_SEC
from .scanner import Scanner
from .store import Store

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("signal-desk")

CFG = config.load()
STATIC = config.BASE_DIR / "app" / "static"
store = Store(CFG["data_dir"] / "signals.db")
scanner = Scanner(CFG, store)
assistant = Assistant(CFG, scanner)


def clean(o):
    """NaN/Unendlich -> None, damit der Browser das JSON lesen kann."""
    if hasattr(o, "item") and not isinstance(o, (list, dict, str)):  # numpy-Zahlen/-Bools
        o = o.item()
    if isinstance(o, bool):
        return o
    if isinstance(o, float):
        return o if math.isfinite(o) else None
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    return o


def J(data, status: int = 200) -> JSONResponse:
    return JSONResponse(clean(data), status_code=status, headers={"Cache-Control": "no-store"})


# ---------------------------------------------------------------------------
# Passwortschutz (HTTP Basic), aktiv sobald DASHBOARD_PASSWORD gesetzt ist
# ---------------------------------------------------------------------------
class BasicAuth(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        pw = CFG["secrets"]["dashboard_password"]
        if not pw or request.url.path == "/api/health":
            return await call_next(request)
        header = request.headers.get("authorization", "")
        if header.lower().startswith("basic "):
            try:
                user, _, given = base64.b64decode(header[6:]).decode("utf-8").partition(":")
                if secrets.compare_digest(user, CFG["secrets"]["dashboard_user"]) and secrets.compare_digest(given, pw):
                    return await call_next(request)
            except Exception:  # noqa: BLE001
                pass
        return Response("Anmeldung erforderlich", status_code=401, headers={"WWW-Authenticate": 'Basic realm="Signal-Desk"'})


# ---------------------------------------------------------------------------
# Seiten
# ---------------------------------------------------------------------------
async def index(request: Request):
    return FileResponse(STATIC / "index.html", headers={"Cache-Control": "no-cache"})


async def fear_greed_page(request: Request):
    return FileResponse(STATIC / "fear-greed.html", headers={"Cache-Control": "no-cache"})


async def health(request: Request):
    return J({"ok": True, "time": int(time.time())})


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------
async def api_meta(request: Request):
    return J({
        "demo": CFG["demo"],
        "timeframes": CFG["timeframes"],
        "tf_labels": TF_LABEL,
        "criteria": [{"key": k, "label": LABELS[k]} for k in ORDER],
        "min_factors": CFG["signal"].get("min_factors", 3),
        "min_score": CFG["signal"].get("min_score", 4.0),
        "assistant": "claude" if assistant.has_claude else "befehle",
        "telegram": bool(CFG["secrets"]["telegram_token"] and CFG["secrets"]["telegram_chat_id"] and CFG["telegram"].get("enabled")),
        "markets": [m.to_dict() for m in scanner.markets],
    })


async def api_overview(request: Request):
    return J({
        "status": scanner.status | {"now": int(time.time()), "errors": list(scanner.errors)[-5:]},
        "rows": scanner.overview(),
        "stats": store.stats(),
        "demo": CFG["demo"],
    })


async def api_chart(request: Request):
    q = request.query_params
    tf = q.get("tf", CFG["timeframes"][0])
    if tf not in TF_SEC:
        return J({"error": "Unbekannte Zeiteinheit"}, 400)
    m = scanner.find_market(q.get("symbol", ""))
    if not m:
        return J({"error": "Markt nicht gefunden"}, 404)
    try:
        candles = await scanner.chart_candles(m, tf)
    except Exception as e:  # noqa: BLE001
        log.info("Chart %s %s: %s", m.symbol, tf, e)
        return J({"error": f"Kursdaten von {m.source} gerade nicht erreichbar ({type(e).__name__})"}, 502)
    res = await asyncio.to_thread(scanner.analyze_candles, candles)
    closed = [k for k in candles if not k.get("live")][-int(CFG["candles"]):]
    live = [k for k in candles if k.get("live")][-1:]
    return J({
        "market": m.to_dict(), "tf": tf,
        "candles": [{k: c[k] for k in ("t", "o", "h", "l", "c", "v")} | {"live": bool(c.get("live"))} for c in closed + live],
        "analysis": res,
        "signals": store.recent(30, m.symbol, tf),
        "demo": CFG["demo"],
    })


async def api_signals(request: Request):
    limit = min(500, int(request.query_params.get("limit", 100)))
    return J({"signals": store.recent(limit), "stats": store.stats()})


async def api_news(request: Request):
    q = (request.query_params.get("q") or "").strip().lower()
    items = scanner.news
    if q:
        terms = [t for t in q.split(",") if t]
        items = [n for n in items if any(t in (n["title"] + " " + n.get("summary", "")).lower() for t in terms)]
    return J({"items": items, "errors": scanner.news_errors, "demo": CFG["demo"]})


async def api_feargreed(request: Request):
    return J(scanner.fng or {"error": "Noch nicht geladen"}, 200 if scanner.fng else 503)


async def api_assistant(request: Request):
    try:
        body = await request.json()
    except Exception:  # noqa: BLE001
        return J({"error": "Ungültige Anfrage"}, 400)
    msg = str(body.get("message", "")).strip()[:1000]
    if not msg:
        return J({"error": "Leere Nachricht"}, 400)
    out = await asyncio.to_thread(assistant.ask, msg, body.get("history") or [], body.get("context") or {})
    return J(out)


@contextlib.asynccontextmanager
async def lifespan(app):
    log.info("Signal-Desk startet (Demo: %s, Börse: %s, Zeiteinheiten: %s)", CFG["demo"], CFG["exchange"], CFG["timeframes"])
    tasks = [asyncio.create_task(scanner.run()), asyncio.create_task(scanner.news_loop()),
             asyncio.create_task(scanner.fng_loop())]
    yield
    for t in tasks:
        t.cancel()


app = Starlette(
    routes=[
        Route("/", index),
        Route("/fear-greed", fear_greed_page),
        Route("/api/health", health),
        Route("/api/meta", api_meta),
        Route("/api/overview", api_overview),
        Route("/api/chart", api_chart),
        Route("/api/signals", api_signals),
        Route("/api/news", api_news),
        Route("/api/feargreed", api_feargreed),
        Route("/api/assistant", api_assistant, methods=["POST"]),
        Mount("/static", StaticFiles(directory=str(STATIC)), name="static"),
    ],
    middleware=[Middleware(BasicAuth), Middleware(GZipMiddleware, minimum_size=1000)],
    lifespan=lifespan,
)
