"""News (RSS/Atom) und der Krypto Fear & Greed Index (alternative.me)."""
from __future__ import annotations

import html
import logging
import re
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime

import requests

from .markets import UA

log = logging.getLogger("signal-desk.feeds")

FNG_DE = {
    "Extreme Fear": "Extreme Angst",
    "Fear": "Angst",
    "Neutral": "Neutral",
    "Greed": "Gier",
    "Extreme Greed": "Extreme Gier",
}


def classify_de(value: int) -> str:
    if value <= 24:
        return "Extreme Angst"
    if value <= 44:
        return "Angst"
    if value <= 55:
        return "Neutral"
    if value <= 74:
        return "Gier"
    return "Extreme Gier"


def fetch_fear_greed(days: int = 90) -> dict:
    r = requests.get("https://api.alternative.me/fng/", params={"limit": days, "format": "json"}, headers=UA, timeout=15)
    r.raise_for_status()
    data = r.json()["data"]
    hist = sorted(({"t": int(x["timestamp"]), "v": int(x["value"])} for x in data), key=lambda x: x["t"])
    cur = data[0]
    value = int(cur["value"])
    return {
        "value": value,
        "label": FNG_DE.get(cur.get("value_classification", ""), classify_de(value)),
        "timestamp": int(cur["timestamp"]),
        "next_update_s": int(cur.get("time_until_update") or 0),
        "history": hist,
        "source": "alternative.me",
        "fetched_at": int(time.time()),
    }


def demo_fear_greed() -> dict:
    import math
    now = int(time.time()) // 86400 * 86400
    hist = [{"t": now - (89 - k) * 86400, "v": int(48 + 22 * math.sin(k / 9) + 6 * math.sin(k / 2.3))} for k in range(90)]
    v = hist[-1]["v"]
    return {"value": v, "label": classify_de(v), "timestamp": now, "next_update_s": 0, "history": hist,
            "source": "Demo-Daten", "fetched_at": int(time.time()), "demo": True}


# ---------------------------------------------------------------------------
# News
# ---------------------------------------------------------------------------
TAG_RE = re.compile(r"<[^>]+>")


def _text(el) -> str:
    return html.unescape(TAG_RE.sub("", (el.text or "") if el is not None else "")).strip()


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def _parse_date(s: str) -> int | None:
    if not s:
        return None
    s = s.strip()
    try:
        return int(parsedate_to_datetime(s).timestamp())
    except Exception:  # noqa: BLE001
        pass
    try:
        return int(datetime.fromisoformat(s.replace("Z", "+00:00")).timestamp())
    except Exception:  # noqa: BLE001
        return None


def parse_feed(xml_bytes: bytes, source: str) -> list[dict]:
    root = ET.fromstring(xml_bytes)
    items = []
    for el in root.iter():
        name = _local(el.tag)
        if name not in ("item", "entry"):
            continue
        title, link, date, summary = "", "", None, ""
        for ch in el:
            n = _local(ch.tag)
            if n == "title":
                title = _text(ch)
            elif n == "link":
                link = (ch.get("href") or ch.text or "").strip() or link
            elif n in ("pubDate", "published", "updated", "date") and date is None:
                date = _parse_date(ch.text or "")
            elif n in ("description", "summary") and not summary:
                summary = _text(ch)[:220]
        if title and link:
            items.append({"title": title, "url": link, "source": source, "published": date, "summary": summary})
    return items


def fetch_news(feeds: list[dict], max_items: int = 60) -> tuple[list[dict], list[str]]:
    all_items, errors = [], []
    for f in feeds:
        try:
            r = requests.get(f["url"], headers=UA, timeout=15)
            r.raise_for_status()
            all_items += parse_feed(r.content, f["name"])
        except Exception as e:  # noqa: BLE001
            errors.append(f"{f['name']}: {e}")
            log.info("Feed %s fehlgeschlagen: %s", f["name"], e)
    seen, out = set(), []
    for it in sorted(all_items, key=lambda x: x["published"] or 0, reverse=True):
        key = it["title"].lower()[:80]
        if key in seen:
            continue
        seen.add(key)
        out.append(it)
    return out[:max_items], errors


def demo_news() -> list[dict]:
    now = int(time.time())
    titles = [
        ("Demo: Hier erscheinen im Live-Betrieb die Schlagzeilen deiner RSS-Feeds", "Demo"),
        ("Demo: Mit dem Schalter oben filterst du auf den gewählten Markt, z. B. Bitcoin", "Demo"),
        ("Demo: Feeds trägst du in der config.yaml unter news.feeds ein", "Demo"),
        ("Demo: Ein Klick auf eine Schlagzeile öffnet den Artikel in einem neuen Tab", "Demo"),
    ]
    return [{"title": t, "url": "#", "source": s, "published": now - k * 1800, "summary": "", "demo": True}
            for k, (t, s) in enumerate(titles)]
