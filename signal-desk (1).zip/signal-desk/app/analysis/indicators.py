"""Grundbausteine der Chartanalyse.

Alle Funktionen arbeiten auf numpy-Arrays und nur mit GESCHLOSSENEN Kerzen.
Enthält: EMA, ATR, ZigZag-Swings, Volumenprofil, Support/Widerstand-Zonen
und einen "Spiegel", mit dem jede bullische Mustererkennung auch bärisch
funktioniert (Preise werden negiert, Hochs und Tiefs getauscht).
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace

import numpy as np


# ---------------------------------------------------------------------------
# Datenstruktur
# ---------------------------------------------------------------------------
@dataclass
class Series:
    t: np.ndarray  # Unix-Sekunden (Kerzen-Öffnungszeit)
    o: np.ndarray
    h: np.ndarray
    l: np.ndarray
    c: np.ndarray
    v: np.ndarray

    @property
    def n(self) -> int:
        return len(self.c)

    @classmethod
    def from_candles(cls, candles: list[dict]) -> "Series":
        return cls(
            t=np.array([int(k["t"]) for k in candles], dtype=np.int64),
            o=np.array([float(k["o"]) for k in candles]),
            h=np.array([float(k["h"]) for k in candles]),
            l=np.array([float(k["l"]) for k in candles]),
            c=np.array([float(k["c"]) for k in candles]),
            v=np.array([float(k["v"]) for k in candles]),
        )


# ---------------------------------------------------------------------------
# Indikatoren
# ---------------------------------------------------------------------------
def ema(x: np.ndarray, n: int) -> np.ndarray:
    x = np.asarray(x, dtype=float)
    out = np.empty_like(x)
    if len(x) == 0:
        return out
    a = 2.0 / (n + 1)
    out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = a * x[i] + (1 - a) * out[i - 1]
    return out


def atr(h: np.ndarray, l: np.ndarray, c: np.ndarray, n: int = 14) -> np.ndarray:
    """Average True Range nach Wilder."""
    prev_c = np.concatenate([[c[0]], c[:-1]])
    tr = np.maximum(h - l, np.maximum(np.abs(h - prev_c), np.abs(l - prev_c)))
    out = np.empty_like(tr)
    k = min(n, len(tr))
    out[:k] = np.cumsum(tr[:k]) / np.arange(1, k + 1)
    for i in range(k, len(tr)):
        out[i] = (out[i - 1] * (n - 1) + tr[i]) / n
    return np.maximum(out, 1e-12)


def mean_prev(x: np.ndarray, end: int, n: int) -> float:
    """Mittelwert der n Werte VOR Index end (end selbst nicht enthalten)."""
    start = max(0, end - n)
    seg = x[start:end]
    return float(seg.mean()) if len(seg) else float("nan")


# ---------------------------------------------------------------------------
# Swings (ZigZag)
# ---------------------------------------------------------------------------
@dataclass
class Swing:
    i: int          # Kerzenindex
    price: float
    kind: str       # "H" = Hoch, "L" = Tief
    confirmed: bool  # False = aktuelles, noch nicht bestätigtes Extrem


def zigzag(h: np.ndarray, l: np.ndarray, atr_arr: np.ndarray, mult: float) -> list[Swing]:
    """Wechselnde Hochs/Tiefs. Ein Swing gilt als bestätigt, sobald der Kurs
    um mindestens mult * ATR in die Gegenrichtung gelaufen ist."""
    n = len(h)
    swings: list[Swing] = []
    if n < 3:
        return swings
    hi_i = lo_i = 0
    direction = 0  # 1 = suche Hoch, -1 = suche Tief
    ext = 0
    for i in range(1, n):
        thr = mult * atr_arr[i]
        if direction == 0:
            if h[i] > h[hi_i]:
                hi_i = i
            if l[i] < l[lo_i]:
                lo_i = i
            if h[hi_i] - l[lo_i] >= thr:
                if hi_i > lo_i:
                    swings.append(Swing(lo_i, float(l[lo_i]), "L", True))
                    direction, ext = 1, hi_i
                else:
                    swings.append(Swing(hi_i, float(h[hi_i]), "H", True))
                    direction, ext = -1, lo_i
            continue
        if direction == 1:
            if h[i] >= h[ext]:
                ext = i
            elif h[ext] - l[i] >= thr:
                swings.append(Swing(ext, float(h[ext]), "H", True))
                seg = l[ext + 1:i + 1]
                ext = ext + 1 + int(np.argmin(seg))
                direction = -1
        else:
            if l[i] <= l[ext]:
                ext = i
            elif h[i] - l[ext] >= thr:
                swings.append(Swing(ext, float(l[ext]), "L", True))
                seg = h[ext + 1:i + 1]
                ext = ext + 1 + int(np.argmax(seg))
                direction = 1
    if direction == 1:
        swings.append(Swing(ext, float(h[ext]), "H", False))
    elif direction == -1:
        swings.append(Swing(ext, float(l[ext]), "L", False))
    return swings


# ---------------------------------------------------------------------------
# Volumenprofil
# ---------------------------------------------------------------------------
def volume_profile(h: np.ndarray, l: np.ndarray, v: np.ndarray, bins: int = 40) -> dict:
    lo, hi = float(l.min()), float(h.max())
    if hi <= lo:
        hi = lo * 1.001 + 1e-9
    width = (hi - lo) / bins
    vol = np.zeros(bins)
    for hh, ll, vv in zip(h, l, v):
        a = min(bins - 1, max(0, int((ll - lo) / width)))
        b = min(bins - 1, max(0, int((hh - lo) / width)))
        vol[a:b + 1] += vv / (b - a + 1)
    poc = int(np.argmax(vol))
    total = vol.sum()
    lo_i = hi_i = poc
    acc = vol[poc]
    while acc < 0.7 * total and (lo_i > 0 or hi_i < bins - 1):
        up = vol[hi_i + 1] if hi_i + 1 < bins else -1.0
        dn = vol[lo_i - 1] if lo_i - 1 >= 0 else -1.0
        if up >= dn:
            hi_i += 1
            acc += up
        else:
            lo_i -= 1
            acc += dn
    edges = [lo + k * width for k in range(bins + 1)]
    return {
        "bins": [
            {"from": edges[k], "to": edges[k + 1], "vol": float(vol[k])} for k in range(bins)
        ],
        "poc": (edges[poc] + edges[poc + 1]) / 2,
        "vah": edges[hi_i + 1],
        "val": edges[lo_i],
    }


# ---------------------------------------------------------------------------
# Support / Widerstand
# ---------------------------------------------------------------------------
@dataclass
class Level:
    price: float
    touches: int
    last_i: int
    members: list = field(default_factory=list)


def sr_levels(swings: list[Swing], tol: float, min_touches: int = 2, since: int = 0) -> list[Level]:
    pts = sorted((s for s in swings if s.confirmed and s.i >= since), key=lambda s: s.price)
    clusters: list[list[Swing]] = []
    for s in pts:
        if clusters:
            mean = sum(x.price for x in clusters[-1]) / len(clusters[-1])
            if abs(s.price - mean) <= tol:
                clusters[-1].append(s)
                continue
        clusters.append([s])
    levels = []
    for cl in clusters:
        if len(cl) >= min_touches:
            levels.append(
                Level(
                    price=sum(x.price for x in cl) / len(cl),
                    touches=len(cl),
                    last_i=max(x.i for x in cl),
                    members=cl,
                )
            )
    return levels


# ---------------------------------------------------------------------------
# Analyse-Kontext (+ Spiegelung für bärische Muster)
# ---------------------------------------------------------------------------
@dataclass
class Ctx:
    s: Series
    atr: np.ndarray
    ema20: np.ndarray
    ema50: np.ndarray
    ema200: np.ndarray
    zz_minor: list[Swing]
    zz_mid: list[Swing]
    zz_major: list[Swing]
    mirrored: bool = False

    @property
    def n(self) -> int:
        return self.s.n

    @property
    def last(self) -> int:
        return self.s.n - 1

    @property
    def a(self) -> float:
        return float(self.atr[self.last])

    def p(self, price: float) -> float:
        """Rechnet einen Preis aus der (evtl. gespiegelten) Welt zurück."""
        return -price if self.mirrored else price

    def mirror(self) -> "Ctx":
        s = self.s
        ms = Series(t=s.t, o=-s.o, h=-s.l, l=-s.h, c=-s.c, v=s.v)

        def flip(sw: list[Swing]) -> list[Swing]:
            return [replace(x, price=-x.price, kind="L" if x.kind == "H" else "H") for x in sw]

        return Ctx(
            s=ms,
            atr=self.atr,
            ema20=-self.ema20,
            ema50=-self.ema50,
            ema200=-self.ema200,
            zz_minor=flip(self.zz_minor),
            zz_mid=flip(self.zz_mid),
            zz_major=flip(self.zz_major),
            mirrored=not self.mirrored,
        )


def build_ctx(s: Series) -> Ctx:
    a = atr(s.h, s.l, s.c, 14)
    return Ctx(
        s=s,
        atr=a,
        ema20=ema(s.c, 20),
        ema50=ema(s.c, 50),
        ema200=ema(s.c, 200),
        zz_minor=zigzag(s.h, s.l, a, 1.2),
        zz_mid=zigzag(s.h, s.l, a, 2.0),
        zz_major=zigzag(s.h, s.l, a, 3.0),
    )


def line_at(i1: int, p1: float, i2: int, p2: float, i: float) -> float:
    if i2 == i1:
        return p1
    return p1 + (p2 - p1) * (i - i1) / (i2 - i1)
