"""Deutsche Zahlenformatierung für Texte in Signalen und Telegram."""


def num(x: float, decimals: int = 1) -> str:
    s = f"{x:,.{decimals}f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".")


def price(p: float) -> str:
    ap = abs(p)
    if ap >= 1000:
        d = 0 if ap >= 10000 else 1
    elif ap >= 100:
        d = 2
    elif ap >= 1:
        d = 3
    elif ap >= 0.01:
        d = 4
    else:
        d = 8
    return num(p, d)
