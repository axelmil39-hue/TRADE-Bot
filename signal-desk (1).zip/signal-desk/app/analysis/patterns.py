"""Die 10 Signal-Kriterien.

Jedes Kriterium liefert ein Finding:
  direction  bull | bear | neutral
  active     zählt als bestätigter Faktor für ein Signal
  trigger    Ereignis auf der letzten geschlossenen Kerze (Ausbruch, Abpraller, Umkehrkerze)
  strength   0..1 (wird mit dem Gewicht aus der config.yaml multipliziert)
  state      none | info | forming | confirmed

Bullische Muster sind einmal programmiert; die bärische Variante entsteht über
ctx.mirror() (Preise gespiegelt). Deshalb tauchen in den Funktionen nur
"bullische" Begriffe auf; Texte und Richtung werden über ctx.mirrored gewählt.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, field

import numpy as np

from . import fmt
from .indicators import Ctx, line_at, mean_prev, sr_levels, volume_profile

LABELS = {
    "engulfing": "Engulfing",
    "fibonacci": "Fibonacci-Retracement",
    "volume_profile": "Volumenprofil",
    "volume": "Volumen",
    "support_resistance": "Support & Widerstand",
    "trend": "Auf- & Abwärtstrend",
    "triangle": "Auf- & absteigendes Dreieck",
    "flag": "Bull- & Bear-Flagge",
    "cup_handle": "Cup & Handle",
    "head_shoulders": "Kopf-Schulter + invers",
}
ORDER = list(LABELS)

STATE_RANK = {"none": 0, "info": 1, "forming": 2, "confirmed": 3}


@dataclass
class Finding:
    key: str
    direction: str = "neutral"
    active: bool = False
    trigger: bool = False
    strength: float = 0.0
    state: str = "none"
    text: str = "Nicht erkannt"
    target: float | None = None
    invalidation: float | None = None
    drawings: list = field(default_factory=list)
    meta: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = asdict(self)
        d["label"] = LABELS[self.key]
        d["strength"] = round(float(self.strength), 2)
        d["active"], d["trigger"] = bool(self.active), bool(self.trigger)
        return d


# ---------------------------------------------------------------------------
# Hilfen
# ---------------------------------------------------------------------------
def _dir(ctx: Ctx) -> str:
    return "bear" if ctx.mirrored else "bull"


def _t(ctx: Ctx, i: int) -> int:
    return int(ctx.s.t[int(i)])


def _line(ctx: Ctx, pts: list[tuple[int, float]], label: str = "", style: str = "pattern", dirn: str | None = None) -> dict:
    return {
        "type": "line",
        "points": [[_t(ctx, i), float(ctx.p(p))] for i, p in pts],
        "label": label,
        "style": style,
        "dir": dirn or _dir(ctx),
    }


def _hline(ctx: Ctx, price: float, label: str, style: str, from_i: int | None = None) -> dict:
    d = {"type": "hline", "price": float(ctx.p(price)), "label": label, "style": style}
    if from_i is not None:
        d["from_t"] = _t(ctx, from_i)
    return d


def _marker(ctx: Ctx, i: int, price: float, label: str) -> dict:
    return {"type": "marker", "t": _t(ctx, i), "price": float(ctx.p(price)), "label": label, "dir": _dir(ctx)}


def _rank(f: Finding | None) -> tuple:
    if f is None:
        return (-1, 0, 0)
    return (1 if f.active else 0, STATE_RANK.get(f.state, 0), f.strength)


def pick(key: str, *cands: Finding | None, empty: str = "Nicht erkannt") -> Finding:
    best = max(cands, key=_rank, default=None)
    if best is None:
        return Finding(key, text=empty)
    return best


# ---------------------------------------------------------------------------
# 1. Engulfing
# ---------------------------------------------------------------------------
def _engulf_at(ctx: Ctx, i: int):
    s = ctx.s
    j = i - 1
    if j < 1:
        return None
    a = ctx.atr[i]
    body_i = s.c[i] - s.o[i]   # grüne Kerze
    body_j = s.o[j] - s.c[j]   # rote Vorkerze
    if body_i <= 0 or body_j <= 0 or body_i < 0.4 * a or body_i <= body_j:
        return None
    eps = 0.05 * a
    if s.c[i] >= s.o[j] and s.o[i] <= s.c[j] + eps:
        context = s.c[j] < ctx.ema20[j] or s.c[j] < s.c[max(0, j - 5)]
        return body_i / body_j, context
    return None


def _engulfing_side(ctx: Ctx) -> Finding | None:
    i = ctx.last
    name = "Bearish Engulfing" if ctx.mirrored else "Bullish Engulfing"
    r = _engulf_at(ctx, i)
    if r:
        ratio, context = r
        f = Finding("engulfing", _dir(ctx), active=True, trigger=True, state="confirmed",
                    strength=1.0 if context else 0.6)
        f.text = (f"{name} auf der letzten Kerze, Körper {fmt.num(ratio)}× so groß wie davor"
                  + ("; nach Gegenbewegung, also Umkehrsignal" if context else "; ohne vorherige Gegenbewegung, daher schwächer"))
        f.invalidation = float(ctx.p(min(ctx.s.l[i], ctx.s.l[i - 1])))
        f.drawings = [_marker(ctx, i, ctx.s.l[i], "Bear. Engulfing" if ctx.mirrored else "Bull. Engulfing")]
        return f
    for back in (1, 2):
        if _engulf_at(ctx, i - back):
            f = Finding("engulfing", _dir(ctx), state="info",
                        text=f"{name} vor {back} Kerze{'n' if back > 1 else ''}, nicht mehr frisch")
            f.drawings = [_marker(ctx, i - back, ctx.s.l[i - back], name)]
            return f
    return None


def detect_engulfing(ctx: Ctx) -> Finding:
    return pick("engulfing", _engulfing_side(ctx), _engulfing_side(ctx.mirror()),
                empty="Kein Engulfing auf den letzten 3 Kerzen")


# ---------------------------------------------------------------------------
# 2. Fibonacci-Retracement
# ---------------------------------------------------------------------------
FIBS = [0.236, 0.382, 0.5, 0.618, 0.786]


def _fib_side(ctx: Ctx) -> Finding | None:
    conf = [x for x in ctx.zz_major if x.confirmed]
    if len(conf) < 2:
        return None
    A, B = conf[-2], conf[-1]
    if not (A.kind == "L" and B.kind == "H"):
        return None
    s, i, a = ctx.s, ctx.last, ctx.a
    lo, hi = A.price, B.price
    rng = hi - lo
    if rng < 3 * a or B.i >= i:
        return None
    lvl = {r: hi - rng * r for r in FIBS}
    retr_close = (hi - s.c[i]) / rng
    retr_low = (hi - s.l[i]) / rng
    deepest = (hi - s.l[B.i + 1:i + 1].min()) / rng

    leg = "Abwärtsimpuls" if ctx.mirrored else "Aufwärtsimpuls"
    f = Finding("fibonacci", _dir(ctx))
    f.meta = {"leg_from": float(ctx.p(lo)), "leg_to": float(ctx.p(hi)), "retracement": round(float(retr_close), 3)}
    f.drawings = [_hline(ctx, hi - rng * r, f"Fib {r}", "fib", from_i=A.i) for r in [0.0, *FIBS, 1.0]]
    f.drawings.append({"type": "zone", "from": float(ctx.p(lvl[0.5])), "to": float(ctx.p(lvl[0.618])),
                       "from_t": _t(ctx, A.i), "label": "Goldene Zone", "style": "fib"})
    span = f"{fmt.price(ctx.p(lo))} bis {fmt.price(ctx.p(hi))}"

    if deepest > 0.85:
        f.state, f.direction = "info", "neutral"
        f.text = f"{leg} {span} ist ungültig: Kurs lief über 0.786 hinaus"
        return f

    reaction_candle = s.c[i] > s.o[i]
    if reaction_candle and 0.33 <= retr_low <= 0.83 and retr_close <= 0.786:
        nearest = min(FIBS[1:], key=lambda r: abs(r - retr_low))
        f.active = f.trigger = True
        f.state = "confirmed"
        f.strength = 1.0 if 0.45 <= retr_low <= 0.68 else (0.7 if retr_low > 0.68 else 0.6)
        zone = "in der goldenen Zone" if 0.45 <= retr_low <= 0.68 else f"an Fib {nearest}"
        f.text = f"Reaktion {zone} ({fmt.price(ctx.p(lvl[nearest]))}) im {leg} {span}"
        f.target = float(ctx.p(hi))
        f.invalidation = float(ctx.p(lvl[0.786] - 0.2 * a))
    elif 0.45 <= retr_close <= 0.68:
        f.state, f.strength = "forming", 0.4
        f.text = f"Kurs in der goldenen Zone (0.5 bis 0.618) des {leg}s {span}, Reaktionskerze abwarten"
    else:
        f.state, f.direction = "info", "neutral"
        f.text = f"{leg} {span}, aktuell {fmt.num(retr_close * 100, 0)} % zurückgelaufen"
    return f


def detect_fibonacci(ctx: Ctx) -> Finding:
    return pick("fibonacci", _fib_side(ctx), _fib_side(ctx.mirror()),
                empty="Kein ausreichend großer Impuls für ein Retracement")


# ---------------------------------------------------------------------------
# 3. Volumen
# ---------------------------------------------------------------------------
def detect_volume(ctx: Ctx) -> Finding:
    s, i = ctx.s, ctx.last
    avg = mean_prev(s.v, i, 20)
    if not avg or avg <= 0 or np.isnan(avg):
        return Finding("volume", text="Keine Volumendaten verfügbar")
    ratio = float(s.v[i] / avg)
    rng = s.h[i] - s.l[i]
    body = s.c[i] - s.o[i]
    cdir = "bull" if body > 0.1 * rng else ("bear" if body < -0.1 * rng else "neutral")
    word = {"bull": "Aufwärtskerze", "bear": "Abwärtskerze", "neutral": "unentschlossener Kerze"}[cdir]
    f = Finding("volume", meta={"ratio": round(ratio, 2)})
    if ratio >= 1.5 and cdir != "neutral":
        f.direction, f.active, f.state = cdir, True, "confirmed"
        f.strength = 1.0 if ratio >= 2.0 else 0.7
        f.text = f"Volumen {fmt.num(ratio)}× über dem 20er-Schnitt bei {word}"
    elif ratio >= 1.5:
        f.state = "info"
        f.text = f"Hohes Volumen ({fmt.num(ratio)}×), aber bei {word}"
    else:
        f.state = "info"
        f.text = f"Volumen {'schwach' if ratio < 0.6 else 'normal'} ({fmt.num(ratio)}× Schnitt)"
    return f


# ---------------------------------------------------------------------------
# 4. Volumenprofil
# ---------------------------------------------------------------------------
def detect_volume_profile(ctx: Ctx) -> tuple[Finding, dict]:
    s, i, a = ctx.s, ctx.last, ctx.a
    start = max(0, ctx.n - 200)
    vp = volume_profile(s.h[start:], s.l[start:], s.v[start:], 40)
    poc, vah, val = vp["poc"], vp["vah"], vp["val"]
    tol = 0.3 * a
    c, o, h, l, pc = s.c[i], s.o[i], s.h[i], s.l[i], s.c[i - 1]
    green = c > o and (c - o) >= 0.3 * a
    red = c < o and (o - c) >= 0.3 * a
    P = fmt.price
    ev = []
    if c > vah + 0.1 * a and pc <= vah and green:
        ev.append(("bull", 0.9, f"Ausbruch über das Value Area High ({P(vah)})"))
    if c < val - 0.1 * a and pc >= val and red:
        ev.append(("bear", 0.9, f"Rutsch unter das Value Area Low ({P(val)})"))
    if green and l <= val + tol and c >= val + 0.25 * a and pc > val - tol:
        ev.append(("bull", 0.8, f"Abpraller am Value Area Low ({P(val)})"))
    if green and l <= poc + tol and c >= poc + 0.25 * a and pc > poc:
        ev.append(("bull", 0.8, f"Abpraller am Point of Control ({P(poc)})"))
    if red and h >= vah - tol and c <= vah - 0.25 * a and pc < vah + tol:
        ev.append(("bear", 0.8, f"Abweisung am Value Area High ({P(vah)})"))
    if red and h >= poc - tol and c <= poc - 0.25 * a and pc < poc:
        ev.append(("bear", 0.8, f"Abweisung am Point of Control ({P(poc)})"))

    f = Finding("volume_profile", meta={"poc": poc, "vah": vah, "val": val})
    f.drawings = [
        {"type": "hline", "price": poc, "label": "POC", "style": "poc"},
        {"type": "hline", "price": vah, "label": "VAH", "style": "va"},
        {"type": "hline", "price": val, "label": "VAL", "style": "va"},
    ]
    if ev:
        d, st, txt = max(ev, key=lambda e: e[1])
        f.direction, f.strength, f.text = d, st, txt
        f.active = f.trigger = True
        f.state = "confirmed"
    else:
        f.state = "info"
        where = "über" if c > vah else ("unter" if c < val else "innerhalb")
        f.text = f"Kurs {where} der Value Area ({P(val)} bis {P(vah)}), POC bei {P(poc)}"
    return f, vp


# ---------------------------------------------------------------------------
# 5. Support & Widerstand
# ---------------------------------------------------------------------------
def detect_support_resistance(ctx: Ctx) -> Finding:
    s, i, a = ctx.s, ctx.last, ctx.a
    tol = 0.5 * a
    levels = sr_levels(ctx.zz_mid, tol, 2, since=max(0, ctx.n - 250))
    c, o, h, l, pc = s.c[i], s.o[i], s.h[i], s.l[i], s.c[i - 1]
    body, rng = abs(c - o), max(h - l, 1e-12)
    P = fmt.price
    ev = []
    # Nur die beiden Zonen direkt um den Vorkerzen-Schlusskurs zählen
    res_lv = min((L for L in levels if L.price > pc), key=lambda L: L.price - pc, default=None)
    sup_lv = max((L for L in levels if L.price <= pc), key=lambda L: L.price, default=None)
    for L, kind in ((res_lv, "R"), (sup_lv, "S")):
        if L is None:
            continue
        p = L.price
        bonus = min(0.2, 0.05 * (L.touches - 2))
        if kind == "R":
            if c > p + 0.2 * a and body >= 0.4 * a and c > o:
                ev.append(("bull", 0.85 + bonus, f"Ausbruch über Widerstand {P(p)} ({L.touches} Berührungen)"))
            elif c < o and h >= p - 0.35 * a and c <= p - 0.3 * a and (h - max(o, c)) >= 0.3 * rng:
                ev.append(("bear", 0.8 + bonus, f"Abweisung am Widerstand {P(p)} ({L.touches} Berührungen)"))
        else:
            if c < p - 0.2 * a and body >= 0.4 * a and c < o:
                ev.append(("bear", 0.85 + bonus, f"Bruch der Unterstützung {P(p)} ({L.touches} Berührungen)"))
            elif c > o and l <= p + 0.35 * a and c >= p + 0.3 * a and (min(o, c) - l) >= 0.3 * rng:
                ev.append(("bull", 0.8 + bonus, f"Abpraller an Unterstützung {P(p)} ({L.touches} Berührungen)"))
            elif c > o and l <= p + 0.35 * a and c >= p + 0.3 * a and body >= 0.5 * a:
                ev.append(("bull", 0.75 + bonus, f"Abpraller an Unterstützung {P(p)} mit starker Kerze"))
    if res_lv is not None and not ev:
        p = res_lv.price
        if c < o and h >= p - 0.35 * a and c <= p - 0.3 * a and body >= 0.5 * a:
            ev.append(("bear", 0.75, f"Abweisung am Widerstand {P(p)} mit starker Kerze"))

    below = sorted((L for L in levels if L.price < c), key=lambda L: -L.price)[:3]
    above = sorted((L for L in levels if L.price >= c), key=lambda L: L.price)[:3]
    f = Finding("support_resistance")
    f.drawings = [{"type": "hline", "price": L.price, "label": f"S {L.touches}×", "style": "support"} for L in below]
    f.drawings += [{"type": "hline", "price": L.price, "label": f"R {L.touches}×", "style": "resistance"} for L in above]
    f.meta = {"supports": [L.price for L in below], "resistances": [L.price for L in above]}
    if ev:
        d, st, txt = max(ev, key=lambda e: e[1])
        f.direction, f.strength, f.text = d, min(1.0, st), txt
        f.active = f.trigger = True
        f.state = "confirmed"
    else:
        f.state = "info"
        parts = []
        if below:
            parts.append(f"nächste Unterstützung {P(below[0].price)}")
        if above:
            parts.append(f"nächster Widerstand {P(above[0].price)}")
        f.text = ("Keine Reaktion an einer Zone; " + ", ".join(parts)) if parts else "Noch keine Zone mit 2+ Berührungen"
    return f


# ---------------------------------------------------------------------------
# 6. Trend
# ---------------------------------------------------------------------------
def detect_trend(ctx: Ctx) -> Finding:
    s, i, a = ctx.s, ctx.last, ctx.a
    pts, why = 0, []
    c, e50, e200 = s.c[i], ctx.ema50[i], ctx.ema200[i]
    if c > e50 > e200:
        pts += 1
        why.append("Kurs über EMA 50 über EMA 200")
    elif c < e50 < e200:
        pts -= 1
        why.append("Kurs unter EMA 50 unter EMA 200")
    k = min(10, i)
    slope = (ctx.ema50[i] - ctx.ema50[i - k]) / a if k > 0 else 0.0
    if slope > 0.5:
        pts += 1
        why.append("EMA 50 steigt")
    elif slope < -0.5:
        pts -= 1
        why.append("EMA 50 fällt")
    sw = [x for x in ctx.zz_minor if x.confirmed]
    hs = [x for x in sw if x.kind == "H"][-2:]
    ls = [x for x in sw if x.kind == "L"][-2:]
    if len(hs) == 2 and len(ls) == 2:
        hh, hl = hs[1].price > hs[0].price, ls[1].price > ls[0].price
        if hh and hl:
            pts += 1
            why.append("höhere Hochs und Tiefs")
        elif not hh and not hl:
            pts -= 1
            why.append("tiefere Hochs und Tiefs")
    f = Finding("trend", strength=min(1.0, abs(pts) / 3))
    if pts >= 2:
        f.direction, f.active, f.state = "bull", True, "confirmed"
        f.text = "Aufwärtstrend: " + ", ".join(why)
        f.meta = {"trend": "up"}
    elif pts <= -2:
        f.direction, f.active, f.state = "bear", True, "confirmed"
        f.text = "Abwärtstrend: " + ", ".join(why)
        f.meta = {"trend": "down"}
    else:
        f.state, f.strength = "info", 0.0
        f.text = "Seitwärts, kein klarer Trend" + (f" ({', '.join(why)})" if why else "")
        f.meta = {"trend": "side"}
    return f


# ---------------------------------------------------------------------------
# 7. Aufsteigendes / absteigendes Dreieck
# ---------------------------------------------------------------------------
def _triangle_side(ctx: Ctx) -> Finding | None:
    s, i, a = ctx.s, ctx.last, ctx.a
    sw = [x for x in ctx.zz_minor if x.confirmed and x.i >= ctx.n - 90]
    highs = [x for x in sw if x.kind == "H"]
    found = None
    for k in (3, 2):
        if len(highs) < k:
            continue
        top = highs[-k:]
        prices = [x.price for x in top]
        if max(prices) - min(prices) > 0.6 * a:
            continue
        level = max(prices)
        start = max(0, sw.index(top[0]) - 1)
        lows = [x for x in sw[start:] if x.kind == "L"]
        if len(lows) < 2:
            continue
        if any(lows[j + 1].price <= lows[j].price + 0.1 * a for j in range(len(lows) - 1)):
            continue
        height = level - lows[0].price
        if lows[-1].price - lows[0].price < 0.8 * a or height < 1.5 * a or level - lows[-1].price < 0.3 * a:
            continue
        first_i = min(lows[0].i, top[0].i)
        last_touch = max(top[-1].i, lows[-1].i)
        if last_touch - first_i < 8 or i - last_touch > 25:
            continue
        m, b = np.polyfit([x.i for x in lows], [x.price for x in lows], 1)
        if m <= 0:
            continue
        found = (level, m, b, top, lows, first_i, height)
        break
    if not found:
        return None
    level, m, b, top, lows, first_i, height = found
    sup = lambda x: m * x + b  # noqa: E731
    c = s.c
    brk = next((j for j in range(top[-1].i + 1, i + 1) if c[j] > level + 0.1 * a), None)
    name = "Absteigendes Dreieck" if ctx.mirrored else "Aufsteigendes Dreieck"
    flat = "Unterstützung" if ctx.mirrored else "Widerstand"
    f = Finding("triangle", _dir(ctx), target=float(ctx.p(level + height)), invalidation=float(ctx.p(sup(i))))
    f.drawings = [
        _line(ctx, [(first_i, level), (i, level)], name),
        _line(ctx, [(lows[0].i, sup(lows[0].i)), (i, sup(i))], ""),
    ]
    if brk is not None:
        if i - brk > 3 or c[i] <= level:
            return None
        f.active, f.state = True, "confirmed"
        f.trigger = brk == i
        f.strength = 1.0 if f.trigger else 0.75
        verb = "Bruch der" if ctx.mirrored else "Ausbruch über den"
        f.text = f"{name}: {verb} {flat} {fmt.price(ctx.p(level))}" + ("" if f.trigger else f" vor {i - brk} Kerze(n)")
        return f
    if c[i] < sup(i) - 0.1 * a:
        f.direction, f.state = "neutral", "info"
        f.text = f"{name} wurde entgegen der Erwartung aufgelöst"
        return f
    if sup(i) >= level - 0.1 * a:
        return None
    f.state, f.strength = "forming", 0.4
    f.text = f"{name} in Formation: {flat} {fmt.price(ctx.p(level))}, Ausbruch abwarten"
    return f


def detect_triangle(ctx: Ctx) -> Finding:
    return pick("triangle", _triangle_side(ctx), _triangle_side(ctx.mirror()),
                empty="Kein Dreieck in den letzten 90 Kerzen")


# ---------------------------------------------------------------------------
# 8. Bull- / Bear-Flagge
# ---------------------------------------------------------------------------
def _flag_side(ctx: Ctx) -> Finding | None:
    s, i = ctx.s, ctx.last
    h, l, c, v = s.h, s.l, s.c, s.v
    lo_b, hi_b = max(0, i - 21), i - 3
    if hi_b <= lo_b + 1:
        return None
    t_i = lo_b + int(np.argmax(h[lo_b:hi_b + 1]))
    top = h[t_i]
    if h[t_i + 1:i].max() > top:
        return None
    ps = max(0, t_i - 20)
    if t_i - ps < 2:
        return None
    p_i = ps + int(np.argmin(l[ps:t_i]))
    pole, pole_bars = top - l[p_i], t_i - p_i
    a0 = float(ctx.atr[p_i])
    if pole_bars < 2 or pole < 4 * a0 or pole / pole_bars < 0.6 * a0:
        return None
    if (top - l[t_i + 1:i + 1].min()) / pole > 0.5:
        return None
    if i - t_i > max(3 * pole_bars, 8):
        return None
    xs_h = np.arange(t_i, i)          # Oberkante inkl. Flaggenmast-Spitze
    xs_l = np.arange(t_i + 1, i)
    if len(xs_l) < 2:
        return None
    mh, bh = np.polyfit(xs_h, h[xs_h], 1)
    ml, bl = np.polyfit(xs_l, l[xs_l], 1)
    mid = (mh + ml) / 2
    if mid > 0.15 * a0 or mid < -pole / pole_bars:
        return None
    upper = lambda x: mh * x + bh  # noqa: E731
    lower = lambda x: ml * x + bl  # noqa: E731
    vol_ok = v[t_i + 1:i].mean() < v[p_i:t_i + 1].mean()
    name = "Bear-Flagge" if ctx.mirrored else "Bull-Flagge"
    f = Finding("flag", _dir(ctx), target=float(ctx.p(upper(i) + pole)), invalidation=float(ctx.p(l[t_i + 1:i + 1].min())))
    f.drawings = [
        _line(ctx, [(p_i, l[p_i]), (t_i, top)], name),
        _line(ctx, [(t_i, upper(t_i)), (i, upper(i))], ""),
        _line(ctx, [(t_i + 1, lower(t_i + 1)), (i, lower(i))], ""),
    ]
    f.meta = {"volume_drying_up": bool(vol_ok)}
    if c[i] > upper(i):
        f.active, f.state = True, "confirmed"
        f.trigger = c[i - 1] <= upper(i - 1)
        f.strength = (1.0 if vol_ok else 0.8) if f.trigger else 0.7
        dirw = "nach unten" if ctx.mirrored else "nach oben"
        f.text = (f"{name}: Ausbruch {dirw} aus dem Kanal" + ("" if f.trigger else " (vor 1 Kerze)")
                  + ("; Volumen in der Flagge rückläufig" if vol_ok else ""))
        return f
    if c[i] >= lower(i) - 0.2 * ctx.a:
        f.state, f.strength = "forming", 0.4
        f.text = f"{name} in Formation: Ausbruch über {fmt.price(ctx.p(upper(i)))} abwarten" if not ctx.mirrored \
            else f"{name} in Formation: Bruch unter {fmt.price(ctx.p(upper(i)))} abwarten"
        return f
    return None


def detect_flag(ctx: Ctx) -> Finding:
    return pick("flag", _flag_side(ctx), _flag_side(ctx.mirror()), empty="Keine Flagge nach starkem Impuls")


# ---------------------------------------------------------------------------
# 9. Cup & Handle (bullisch)
# ---------------------------------------------------------------------------
def detect_cup_handle(ctx: Ctx) -> Finding:
    s, i, a = ctx.s, ctx.last, ctx.a
    h, l, c = s.h, s.l, s.c
    empty = Finding("cup_handle", text="Keine Tasse mit Henkel erkannt")
    lo_b = max(0, i - 20)
    if i - 2 <= lo_b:
        return empty
    r = lo_b + int(np.argmax(h[lo_b:i - 1]))
    rim_r = h[r]
    if h[r + 1:i].max() > rim_r:
        return empty
    best = None
    for L in (x for x in ctx.zz_minor if x.kind == "H" and x.confirmed and r - 150 <= x.i <= r - 15):
        rim_l = L.price
        b = L.i + int(np.argmin(l[L.i:r + 1]))
        bottom = l[b]
        depth = min(rim_l, rim_r) - bottom
        if depth < 4 * a or depth > 0.5 * max(rim_l, rim_r):
            continue
        if abs(rim_l - rim_r) > 0.12 * depth:
            continue
        if h[L.i + 1:r].max() > max(rim_l, rim_r) + 0.05 * depth:
            continue
        pos = (b - L.i) / (r - L.i)
        if not 0.25 <= pos <= 0.75:
            continue
        if (c[L.i:r + 1] < bottom + depth / 3).mean() < 0.3:   # V-Form aussortieren
            continue
        handle_low = l[r + 1:i + 1].min()
        hd = rim_r - handle_low
        if hd > 0.5 * depth or hd < 0.3 * a or handle_low < bottom + 0.5 * depth:
            continue
        if i - r > max(5, (r - L.i) / 2):
            continue
        if best is None or depth > best[3]:
            best = (L, b, bottom, depth, handle_low)
    if best is None:
        return empty
    L, b, bottom, depth, handle_low = best
    hl_i = r + 1 + int(np.argmin(l[r + 1:i + 1]))
    f = Finding("cup_handle", "bull", target=float(rim_r + depth), invalidation=float(handle_low))
    f.drawings = [
        {"type": "curve", "points": [[_t(ctx, L.i), float(L.price)], [_t(ctx, b), float(bottom)], [_t(ctx, r), float(rim_r)]],
         "label": "Cup & Handle", "style": "pattern", "dir": "bull"},
        _line(ctx, [(r, rim_r), (hl_i, handle_low), (i, c[i])], ""),
        _line(ctx, [(L.i, rim_r), (i, rim_r)], "", style="neckline"),
    ]
    if c[i] > rim_r and c[i - 1] <= rim_r:
        f.active = f.trigger = True
        f.state, f.strength = "confirmed", 1.0
        f.text = f"Cup & Handle: Ausbruch über den Rand {fmt.price(rim_r)}, Tasse {i - L.i} Kerzen breit"
    else:
        f.state, f.strength = "forming", 0.4
        f.text = f"Henkel bildet sich, Ausbruch über {fmt.price(rim_r)} abwarten"
    return f


# ---------------------------------------------------------------------------
# 10. Schulter-Kopf-Schulter (+ invers)
# ---------------------------------------------------------------------------
def _hs_side(ctx: Ctx) -> Finding | None:
    """Normale SKS (bärisch). Auf ctx.mirror() angewandt = inverse SKS (bullisch)."""
    s, i, a = ctx.s, ctx.last, ctx.a
    sw = ctx.zz_mid
    ks = [k for k, x in enumerate(sw) if x.kind == "H" and x.confirmed]
    if not ks or ks[-1] < 4:
        return None
    k = ks[-1]
    H1, L1, H2, L2, H3 = sw[k - 4:k + 1]
    if H3.i < i - 45 or H3.i >= i:
        return None
    if s.h[H3.i + 1:i + 1].max() > H3.price:
        return None
    neck = lambda x: line_at(L1.i, L1.price, L2.i, L2.price, x)  # noqa: E731
    height = H2.price - neck(H2.i)
    if height < 2 * a:
        return None
    if H2.price - max(H1.price, H3.price) < max(0.5 * a, 0.12 * height):
        return None
    if H1.price - neck(H1.i) < 0.3 * height or H3.price - neck(H3.i) < 0.3 * height:
        return None
    if abs(H1.price - H3.price) > 0.4 * height or abs(L2.price - L1.price) > 0.6 * height:
        return None
    d1, d2 = H2.i - H1.i, H3.i - H2.i
    if d2 <= 0 or not (1 / 3 <= d1 / d2 <= 3):
        return None
    pre = s.l[max(0, H1.i - 40):H1.i]
    if len(pre) == 0 or pre.min() > min(L1.price, L2.price):
        return None   # kein vorheriger Trend, der umgekehrt werden könnte

    c = s.c
    name = "Inverse Schulter-Kopf-Schulter" if ctx.mirrored else "Schulter-Kopf-Schulter"
    dirn = "bull" if ctx.mirrored else "bear"   # SKS ist im Original bärisch
    f = Finding("head_shoulders", dirn, target=float(ctx.p(neck(i) - height)), invalidation=float(ctx.p(H3.price)))
    f.drawings = [
        _line(ctx, [(H1.i, H1.price), (L1.i, L1.price), (H2.i, H2.price), (L2.i, L2.price), (H3.i, H3.price)], name, dirn=dirn),
        _line(ctx, [(L1.i, L1.price), (i, neck(i))], "Nackenlinie", style="neckline", dirn=dirn),
    ]
    brk = next((j for j in range(H3.i + 1, i + 1) if c[j] < neck(j) - 0.1 * a), None)
    if brk is not None:
        if i - brk > 4 or c[i] >= neck(i):
            return None
        f.active, f.state = True, "confirmed"
        f.trigger = brk == i
        f.strength = 1.0 if f.trigger else 0.75
        verb = "Ausbruch über die" if ctx.mirrored else "Bruch der"
        f.text = f"{name}: {verb} Nackenlinie bei {fmt.price(ctx.p(neck(i)))}" + ("" if f.trigger else f" vor {i - brk} Kerze(n)")
        return f
    f.state, f.strength = "forming", 0.4
    f.text = f"{name} in Formation: rechte Schulter steht, Nackenlinie bei {fmt.price(ctx.p(neck(i)))}"
    return f


def detect_head_shoulders(ctx: Ctx) -> Finding:
    return pick("head_shoulders", _hs_side(ctx), _hs_side(ctx.mirror()),
                empty="Keine Kopf-Schulter-Formation")
