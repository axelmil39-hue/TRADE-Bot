"""Fügt die 10 Kriterien zu einem Signal zusammen.

Regel (alles in der config.yaml einstellbar):
  * Ein Signal entsteht nur, wenn mindestens `min_factors` Kriterien in dieselbe
    Richtung zeigen (Standard: 3),
  * der gewichtete Score der Richtung den der Gegenrichtung um `min_score` übertrifft,
  * und (optional) mindestens ein Kriterium auf der letzten geschlossenen Kerze
    ausgelöst hat (Ausbruch, Abpraller, Umkehrkerze ...).
Dazu werden Einstieg, Stop-Loss und zwei Take-Profits vorgeschlagen.
"""
from __future__ import annotations

import numpy as np

from . import patterns as P
from .indicators import Series, build_ctx

DEFAULT_WEIGHTS = {
    "engulfing": 2.0,
    "fibonacci": 1.5,
    "volume_profile": 1.0,
    "volume": 1.0,
    "support_resistance": 1.5,
    "trend": 1.0,
    "triangle": 2.0,
    "flag": 2.0,
    "cup_handle": 2.5,
    "head_shoulders": 2.5,
}

DEFAULT_RULES = {
    "min_factors": 3,
    "min_score": 4.0,
    "require_trigger": True,
    "min_sl_atr": 0.8,
    "max_sl_atr": 3.0,
    "tp1_r": 1.5,
    "tp2_r": 3.0,
}

MIN_CANDLES = 60


def analyze(candles: list[dict], weights: dict | None = None, rules: dict | None = None) -> dict:
    """candles: nur GESCHLOSSENE Kerzen, älteste zuerst. Liefert ein JSON-fähiges dict."""
    w = {**DEFAULT_WEIGHTS, **(weights or {})}
    r = {**DEFAULT_RULES, **(rules or {})}
    if len(candles) < MIN_CANDLES:
        return {"ok": False, "error": f"Zu wenige Kerzen ({len(candles)}), mindestens {MIN_CANDLES} nötig"}

    s = Series.from_candles(candles)
    ctx = build_ctx(s)
    vp_finding, profile = P.detect_volume_profile(ctx)
    found = {
        "engulfing": P.detect_engulfing(ctx),
        "fibonacci": P.detect_fibonacci(ctx),
        "volume_profile": vp_finding,
        "volume": P.detect_volume(ctx),
        "support_resistance": P.detect_support_resistance(ctx),
        "trend": P.detect_trend(ctx),
        "triangle": P.detect_triangle(ctx),
        "flag": P.detect_flag(ctx),
        "cup_handle": P.detect_cup_handle(ctx),
        "head_shoulders": P.detect_head_shoulders(ctx),
    }
    findings = [found[k] for k in P.ORDER]

    def side(d):
        fs = [f for f in findings if f.active and f.direction == d]
        return fs, sum(w.get(f.key, 1.0) * f.strength for f in fs)

    bull, bull_score = side("bull")
    bear, bear_score = side("bear")

    signal = None
    for d, own, own_s, other, other_s in (("bull", bull, bull_score, bear, bear_score),
                                          ("bear", bear, bear_score, bull, bull_score)):
        if (len(own) >= r["min_factors"] and len(own) > len(other)
                and own_s - other_s >= r["min_score"]
                and (not r["require_trigger"] or any(f.trigger for f in own))):
            signal = d
            break

    i = s.n - 1
    a = float(ctx.atr[i])
    plan = trade_plan(s, a, signal, bull if signal == "bull" else bear, r) if signal else None
    trend = found["trend"].meta.get("trend", "side")

    return {
        "ok": True,
        "candle_time": int(s.t[i]),
        "price": float(s.c[i]),
        "atr": a,
        "trend": trend,
        "bull_score": round(bull_score, 2),
        "bear_score": round(bear_score, 2),
        "net_score": round(bull_score - bear_score, 2),
        "bull_factors": [f.key for f in bull],
        "bear_factors": [f.key for f in bear],
        "min_factors": r["min_factors"],
        "signal": signal,
        "plan": plan,
        "findings": [f.to_dict() for f in findings],
        "profile": profile,
        "ema50": [round(float(x), 10) for x in ctx.ema50],
        "ema200": [round(float(x), 10) for x in ctx.ema200],
    }


def trade_plan(s: Series, a: float, direction: str, factors: list, r: dict) -> dict:
    i = s.n - 1
    entry = float(s.c[i])
    lo5, hi5 = float(np.min(s.l[i - 4:i + 1])), float(np.max(s.h[i - 4:i + 1]))
    if direction == "bull":
        sl = lo5 - 0.2 * a
        sl = min(max(sl, entry - r["max_sl_atr"] * a), entry - r["min_sl_atr"] * a)
        risk = entry - sl
        tp1 = entry + r["tp1_r"] * risk
        targets = [f.target for f in factors if f.target and f.target > tp1]
        tp2 = min(targets) if targets else entry + r["tp2_r"] * risk
    else:
        sl = hi5 + 0.2 * a
        sl = max(min(sl, entry + r["max_sl_atr"] * a), entry + r["min_sl_atr"] * a)
        risk = sl - entry
        tp1 = entry - r["tp1_r"] * risk
        targets = [f.target for f in factors if f.target and 0 < f.target < tp1]
        tp2 = max(targets) if targets else entry - r["tp2_r"] * risk
    return {
        "direction": direction,
        "entry": entry,
        "sl": float(sl),
        "tp1": float(tp1),
        "tp2": float(tp2),
        "risk_pct": round(abs(entry - sl) / entry * 100, 2),
        "crv_tp2": round(abs(tp2 - entry) / max(1e-12, abs(entry - sl)), 2),
    }
