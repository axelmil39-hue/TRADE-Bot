"""Lädt config.yaml und die geheimen Werte aus der Umgebung (.env)."""
from __future__ import annotations

import copy
import os
from pathlib import Path

import yaml

BASE_DIR = Path(__file__).resolve().parent.parent

DEFAULTS = {
    "exchange": "binance",
    "binance_base_url": "https://data-api.binance.vision",
    "bybit_base_url": "https://api.bybit.com",
    "bybit_category": "linear",
    "universe": {"top_n": 100, "extra": [], "exclude": [], "fallback": ["BTC", "ETH", "SOL", "XRP", "BNB"]},
    "commodities": {"enabled": True, "symbols": []},
    "timeframes": ["1h", "4h", "1d"],
    "candles": 300,
    "scan_interval_minutes": 5,
    "concurrency": 6,
    "signal": {},
    "weights": {},
    "telegram": {"enabled": True, "timeframes": ["1h", "4h", "1d"], "min_factors": 3},
    "news": {"refresh_minutes": 10, "max_items": 60, "feeds": []},
    "assistant": {"model": "claude-haiku-5-5", "max_tokens": 500},
}


def _merge(a: dict, b: dict) -> dict:
    out = copy.deepcopy(a)
    for k, v in (b or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def _load_dotenv(path: Path) -> None:
    """Minimaler .env-Leser (kein Zusatzpaket nötig). Vorhandene Umgebungsvariablen gewinnen."""
    if not path.exists():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, val = line.split("=", 1)
        val = val.strip().strip('"').strip("'")
        os.environ.setdefault(key.strip(), val)


def load() -> dict:
    _load_dotenv(BASE_DIR / ".env")
    path = Path(os.environ.get("CONFIG_FILE", BASE_DIR / "config.yaml"))
    user = {}
    if path.exists():
        user = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    cfg = _merge(DEFAULTS, user)
    env = os.environ.get
    cfg["demo"] = env("DEMO_MODE", "0").lower() in ("1", "true", "yes", "ja")
    cfg["data_dir"] = Path(env("DATA_DIR", str(BASE_DIR / "data")))
    cfg["secrets"] = {
        "telegram_token": env("TELEGRAM_BOT_TOKEN", ""),
        "telegram_chat_id": env("TELEGRAM_CHAT_ID", ""),
        "dashboard_user": env("DASHBOARD_USER", "admin"),
        "dashboard_password": env("DASHBOARD_PASSWORD", ""),
        "anthropic_api_key": env("ANTHROPIC_API_KEY", ""),
        "coingecko_api_key": env("COINGECKO_API_KEY", ""),
    }
    if env("ASSISTANT_MODEL"):
        cfg["assistant"]["model"] = env("ASSISTANT_MODEL")
    cfg["timeframes"] = [tf for tf in cfg["timeframes"] if tf in ("15m", "1h", "4h", "1d")] or ["1h"]
    cfg["data_dir"].mkdir(parents=True, exist_ok=True)
    return cfg
