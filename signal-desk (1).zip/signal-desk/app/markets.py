"""Marktdaten: Kerzen von Binance, Bybit (Krypto) und Yahoo Finance (Rohstoffe),
plus die Liste der zu scannenden Märkte (Top-100 nach CoinGecko, ohne Stablecoins).

Alle Abrufe sind synchron (requests) und werden vom Scanner in Threads ausgeführt.
"""
from __future__ import annotations

import logging
import time
from dataclasses import asdict, dataclass

import requests

from . import demo

log = logging.getLogger("signal-desk.markets")

TF_SEC = {"15m": 900, "1h": 3600, "4h": 14400, "1d": 86400}
TF_LABEL = {"15m": "15 Min", "1h": "1 Std", "4h": "4 Std", "1d": "1 Tag"}
UA = {"User-Agent": "Mozilla/5.0 (compatible; Signal-Desk/1.0)"}
TIMEOUT = 15

STABLECOINS = {
    "USDT", "USDC", "DAI", "FDUSD", "TUSD", "USDE", "USDS", "PYUSD", "USDD", "BUSD", "FRAX", "USD1",
    "RLUSD", "EURC", "EURS", "USDP", "GUSD", "LUSD", "USDX", "USDB", "USD0", "SUSDE", "SUSDS", "USDTB",
    "USDF", "USDG", "BFUSD", "USDY", "USDO", "CRVUSD", "GHO", "FXUSD", "SDAI", "USDL", "USTC", "AUSD",
    "BSC-USD", "SYRUPUSDC", "SYRUPUSDT", "USDAI", "USDR", "DOLA", "MIM", "EUROC", "EURT", "XSGD",
}
WRAPPED = {
    "WBTC", "WETH", "STETH", "WSTETH", "WEETH", "EETH", "CBBTC", "RETH", "METH", "CBETH", "BTCB", "LBTC",
    "SOLVBTC", "JITOSOL", "MSOL", "BNSOL", "JUPSOL", "EZETH", "RSETH", "OSETH", "WBETH", "TBTC", "WBNB",
    "CLBTC", "BBSOL", "SAVAX", "STKAAVE", "WTRX", "WHYPE", "KHYPE", "UNIBTC", "ENZOBTC", "PUMPBTC", "FBTC",
}


@dataclass
class Market:
    symbol: str   # z. B. BTCUSDT oder GC=F
    name: str
    kind: str     # crypto | commodity
    source: str   # binance | bybit | yahoo | demo
    base: str = ""
    rank: int | None = None

    def to_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------------------
# Kerzen
# ---------------------------------------------------------------------------
def fetch_candles(m: Market, tf: str, limit: int, cfg: dict) -> list[dict]:
    """Liefert Kerzen (älteste zuerst). Die noch laufende Kerze hat "live": True."""
    if m.source == "demo":
        return demo.demo_candles(m.symbol, tf)
    if m.source == "binance":
        return _binance(cfg["binance_base_url"], m.symbol, tf, limit)
    if m.source == "bybit":
        return _bybit(cfg["bybit_base_url"], cfg["bybit_category"], m.symbol, tf, limit)
    if m.source == "yahoo":
        return _yahoo(m.symbol, tf, limit)
    raise ValueError(f"Unbekannte Datenquelle {m.source}")


def _binance(base: str, symbol: str, tf: str, limit: int) -> list[dict]:
    r = requests.get(f"{base}/api/v3/klines", params={"symbol": symbol, "interval": tf, "limit": min(limit + 1, 1000)},
                     headers=UA, timeout=TIMEOUT)
    r.raise_for_status()
    now_ms = time.time() * 1000
    out = []
    for row in r.json():
        out.append({"t": int(row[0]) // 1000, "o": float(row[1]), "h": float(row[2]), "l": float(row[3]),
                    "c": float(row[4]), "v": float(row[5]), "live": int(row[6]) >= now_ms})
    return out


BYBIT_TF = {"15m": "15", "1h": "60", "4h": "240", "1d": "D"}


def _bybit(base: str, category: str, symbol: str, tf: str, limit: int) -> list[dict]:
    r = requests.get(f"{base}/v5/market/kline",
                     params={"category": category, "symbol": symbol, "interval": BYBIT_TF[tf], "limit": min(limit + 1, 1000)},
                     headers=UA, timeout=TIMEOUT)
    r.raise_for_status()
    data = r.json()
    if data.get("retCode") != 0:
        raise RuntimeError(f"Bybit: {data.get('retMsg')}")
    now = time.time()
    out = []
    for row in reversed(data["result"]["list"]):
        t = int(row[0]) // 1000
        out.append({"t": t, "o": float(row[1]), "h": float(row[2]), "l": float(row[3]),
                    "c": float(row[4]), "v": float(row[5]), "live": t + TF_SEC[tf] > now})
    return out


def _yahoo(symbol: str, tf: str, limit: int) -> list[dict]:
    interval, rng = {"15m": ("15m", "10d"), "1h": ("60m", "60d"), "4h": ("60m", "180d"), "1d": ("1d", "2y")}[tf]
    r = requests.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}",
                     params={"interval": interval, "range": rng}, headers=UA, timeout=TIMEOUT)
    r.raise_for_status()
    res = r.json()["chart"]["result"][0]
    ts = res.get("timestamp") or []
    q = res["indicators"]["quote"][0]
    rows = []
    for k, t in enumerate(ts):
        o, h, l, c, v = q["open"][k], q["high"][k], q["low"][k], q["close"][k], q["volume"][k]
        if None in (o, h, l, c):
            continue
        rows.append({"t": int(t), "o": float(o), "h": float(h), "l": float(l), "c": float(c), "v": float(v or 0)})
    if tf == "4h":
        rows = _resample(rows, 14400)
    elif tf == "1d":
        rows = [{**x, "t": x["t"] - x["t"] % 86400} for x in rows]
    now = time.time()
    for x in rows:
        x["live"] = x["t"] + TF_SEC[tf] > now
    return rows[-(limit + 1):]


def _resample(rows: list[dict], sec: int) -> list[dict]:
    out: list[dict] = []
    for x in rows:
        b = x["t"] - x["t"] % sec
        if out and out[-1]["t"] == b:
            y = out[-1]
            y["h"], y["l"], y["c"], y["v"] = max(y["h"], x["h"]), min(y["l"], x["l"]), x["c"], y["v"] + x["v"]
        else:
            out.append({**x, "t": b})
    return out


# ---------------------------------------------------------------------------
# Marktliste
# ---------------------------------------------------------------------------
def _coingecko_top(api_key: str) -> list[dict]:
    headers = dict(UA)
    if api_key:
        headers["x-cg-demo-api-key"] = api_key
    r = requests.get("https://api.coingecko.com/api/v3/coins/markets",
                     params={"vs_currency": "usd", "order": "market_cap_desc", "per_page": 250, "page": 1},
                     headers=headers, timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


def _is_stable(coin: dict) -> bool:
    sym = (coin.get("symbol") or "").upper()
    if sym in STABLECOINS:
        return True
    price = coin.get("current_price") or 0
    name = (coin.get("name") or "").lower()
    return ("usd" in sym.lower() or "usd" in name or "dollar" in name) and 0.97 <= price <= 1.03


def _exchange_symbols(cfg: dict) -> set[str]:
    if cfg["exchange"] == "bybit":
        r = requests.get(f"{cfg['bybit_base_url']}/v5/market/instruments-info",
                         params={"category": cfg["bybit_category"], "limit": 1000}, headers=UA, timeout=TIMEOUT)
        r.raise_for_status()
        return {x["symbol"] for x in r.json()["result"]["list"] if x.get("status") == "Trading"}
    r = requests.get(f"{cfg['binance_base_url']}/api/v3/ticker/price", headers=UA, timeout=TIMEOUT)
    r.raise_for_status()
    return {x["symbol"] for x in r.json()}


def build_universe(cfg: dict) -> list[Market]:
    if cfg["demo"]:
        return [Market(sym, name, kind, "demo", base=sym.replace("USDT", ""), rank=k + 1)
                for k, (sym, name, kind, _g, _f) in enumerate(DEMO_LIST)]

    uni = cfg["universe"]
    exclude = {x.upper() for x in uni.get("exclude", [])}
    source = "bybit" if cfg["exchange"] == "bybit" else "binance"
    markets: list[Market] = []
    try:
        available = _exchange_symbols(cfg)
    except Exception as e:  # noqa: BLE001
        log.warning("Symbolliste der Börse nicht abrufbar: %s", e)
        available = set()

    def pair_for(base: str) -> str | None:
        for cand in (f"{base}USDT", f"1000{base}USDT", f"1000000{base}USDT"):
            if not available or cand in available:
                return cand
        return None

    coins: list[dict] = []
    try:
        coins = _coingecko_top(cfg["secrets"]["coingecko_api_key"])
    except Exception as e:  # noqa: BLE001
        log.warning("CoinGecko nicht erreichbar, nutze Fallback-Liste: %s", e)

    seen = set()
    if coins:
        picked = [c for c in coins if not _is_stable(c) and (c.get("symbol") or "").upper() not in WRAPPED][: int(uni["top_n"])]
        for c in picked:
            base = c["symbol"].upper()
            if base in exclude or base in seen:
                continue
            pair = pair_for(base)
            if pair:
                seen.add(base)
                markets.append(Market(pair, c.get("name") or base, "crypto", source, base, c.get("market_cap_rank")))
    else:
        for k, base in enumerate(uni.get("fallback", [])):
            base = base.upper()
            pair = pair_for(base)
            if pair and base not in exclude:
                seen.add(base)
                markets.append(Market(pair, base, "crypto", source, base, k + 1))

    for base in uni.get("extra", []):
        base = base.upper()
        if base not in seen and (pair := pair_for(base)):
            markets.append(Market(pair, base, "crypto", source, base, None))

    if cfg["commodities"].get("enabled"):
        for x in cfg["commodities"].get("symbols", []):
            markets.append(Market(x["symbol"], x["name"], "commodity", "yahoo", x["symbol"], None))
    return markets


DEMO_LIST = [(s, n, k, g, f) for s, n, k, g, f in demo.DEMO_MARKETS]
