"""Sprachassistent.

Mit ANTHROPIC_API_KEY: Claude beantwortet Fragen frei und holt sich die Live-Daten
des Bots über Werkzeuge (Marktanalyse, Signale, Fear & Greed, News, Logbuch) und
kann Charts im Dashboard öffnen.
Ohne Schlüssel: eingebaute Sprachbefehle (kostenlos, aber weniger flexibel).

Antworten sind fürs Vorlesen geschrieben: kurz, ohne Aufzählungszeichen.
"""
from __future__ import annotations

import json
import logging
import re

import requests

from .analysis import fmt
from .analysis.patterns import LABELS
from .markets import TF_LABEL

log = logging.getLogger("signal-desk.assistant")

TF_SAY = {"15m": "im 15-Minuten-Chart", "1h": "im Stunden-Chart", "4h": "im 4-Stunden-Chart", "1d": "im Tages-Chart"}
TREND_DE = {"up": "Aufwärtstrend", "down": "Abwärtstrend", "side": "seitwärts"}
TF_ENUM = ["15m", "1h", "4h", "1d"]

SYSTEM = """Du bist der Sprachassistent von Signal-Desk, einem Trading-Dashboard, das Kryptowährungen und Rohstoffe rund um die Uhr scannt.
Ein Signal entsteht, wenn mehrere der 10 Kriterien zusammenpassen: Engulfing, Fibonacci-Retracement, Volumenprofil, Volumen, Support und Widerstand, Trend, auf- und absteigende Dreiecke, Bull- und Bear-Flaggen, Cup and Handle sowie Schulter-Kopf-Schulter und die inverse Variante.

So antwortest du:
- Immer auf Deutsch und so, dass es sich gut vorlesen lässt: 1 bis 4 kurze Sätze, keine Aufzählungszeichen, kein Markdown, keine Emojis.
- Zahlen sinnvoll runden und deutsch schreiben (67.420 statt 67420.13; 2,5 Prozent).
- Hole Kurse, Signale und Analysen IMMER über die Werkzeuge. Erfinde nie Preise oder Signale.
- Wenn der Nutzer einen Chart sehen will oder nach einem bestimmten Markt fragt, öffne ihn mit chart_zeigen.
- Erkläre Fachbegriffe kurz, wenn der Nutzer danach fragt; er lernt noch.
- Du gibst keine Anlageberatung und führst keine Orders aus. Bei Fragen wie "soll ich kaufen" nennst du die Faktenlage und dass die Entscheidung beim Nutzer liegt.
"""

TOOLS = [
    {
        "name": "marktuebersicht",
        "description": "Aktuelle Scanner-Ergebnisse: Märkte mit Signal zuerst, danach nach Stärke sortiert.",
        "input_schema": {"type": "object", "properties": {
            "timeframe": {"type": "string", "enum": TF_ENUM, "description": "optional filtern"},
            "nur_signale": {"type": "boolean"},
            "limit": {"type": "integer", "description": "Anzahl, Standard 8"}}},
    },
    {
        "name": "marktanalyse",
        "description": "Analyse eines Marktes mit allen 10 Kriterien, Trend, Score und ggf. Handelsplan (Einstieg, Stop-Loss, TP1, TP2).",
        "input_schema": {"type": "object", "properties": {
            "markt": {"type": "string", "description": "Name oder Kürzel, z. B. Bitcoin, BTC, Solana, Gold"},
            "timeframe": {"type": "string", "enum": TF_ENUM}}, "required": ["markt"]},
    },
    {"name": "fear_greed", "description": "Krypto Fear & Greed Index: aktueller Wert, Einstufung und Verlauf.",
     "input_schema": {"type": "object", "properties": {}}},
    {
        "name": "news",
        "description": "Neueste Schlagzeilen aus den News-Feeds, optional nach Stichwort gefiltert.",
        "input_schema": {"type": "object", "properties": {
            "suchbegriff": {"type": "string"}, "limit": {"type": "integer"}}},
    },
    {"name": "signal_logbuch", "description": "Letzte Signale mit Ergebnis (TP1, TP2, Stop-Loss, offen) und Trefferquote.",
     "input_schema": {"type": "object", "properties": {"limit": {"type": "integer"}}}},
    {
        "name": "chart_zeigen",
        "description": "Öffnet im Dashboard den Chart eines Marktes in einer Zeiteinheit.",
        "input_schema": {"type": "object", "properties": {
            "markt": {"type": "string"}, "timeframe": {"type": "string", "enum": TF_ENUM}}, "required": ["markt"]},
    },
]


class Assistant:
    def __init__(self, cfg: dict, scanner):
        self.cfg = cfg
        self.sc = scanner

    @property
    def has_claude(self) -> bool:
        return bool(self.cfg["secrets"]["anthropic_api_key"])

    # ------------------------------------------------------------------ Werkzeuge
    def _tf(self, tf: str | None, context: dict) -> str:
        if tf in TF_ENUM:
            return tf
        ctx_tf = (context or {}).get("tf")
        return ctx_tf if ctx_tf in TF_ENUM else self.cfg["timeframes"][0]

    def _analysis(self, market: str, tf: str) -> dict:
        m = self.sc.find_market(market) or self.sc.find_market_in_text(market)
        if not m:
            return {"fehler": f"Markt '{market}' nicht gefunden"}
        row = self.sc.results.get((m.symbol, tf))
        if not row or row.get("error"):
            from .markets import fetch_candles
            candles = fetch_candles(m, tf, int(self.cfg["candles"]), self.cfg)
            res = self.sc.analyze_candles(candles)
            if not res.get("ok"):
                return {"fehler": res.get("error")}
            row = self.sc.summarize(m, tf, candles, res)
        return row

    def run_tool(self, name: str, args: dict, context: dict) -> tuple[dict, dict | None]:
        if name == "marktuebersicht":
            rows = self.sc.overview()
            if args.get("timeframe"):
                rows = [r for r in rows if r["tf"] == args["timeframe"]]
            if args.get("nur_signale"):
                rows = [r for r in rows if r.get("signal")]
            rows = rows[: int(args.get("limit") or 8)]
            return {"maerkte": [self._compact(r) for r in rows], "anzahl_maerkte": len(self.sc.markets)}, None
        if name == "marktanalyse":
            row = self._analysis(args["markt"], self._tf(args.get("timeframe"), context))
            return (self._detail(row) if "fehler" not in row else row), None
        if name == "fear_greed":
            f = self.sc.fng
            if not f:
                return {"fehler": "noch nicht geladen"}, None
            hist = f.get("history", [])
            week = hist[-8]["v"] if len(hist) >= 8 else None
            return {"wert": f["value"], "einstufung": f["label"], "vor_7_tagen": week}, None
        if name == "news":
            q = (args.get("suchbegriff") or "").lower()
            items = [n for n in self.sc.news if not q or q in n["title"].lower()]
            return {"schlagzeilen": [{"titel": n["title"], "quelle": n["source"]} for n in items[: int(args.get("limit") or 5)]]}, None
        if name == "signal_logbuch":
            rows = self.sc.store.recent(int(args.get("limit") or 5))
            return {"statistik": self.sc.store.stats(), "letzte": [
                {"markt": r["name"], "tf": r["timeframe"], "richtung": "long" if r["direction"] == "bull" else "short",
                 "status": r["status_de"], "einstieg": r["entry"]} for r in rows]}, None
        if name == "chart_zeigen":
            m = self.sc.find_market(args["markt"]) or self.sc.find_market_in_text(args["markt"])
            if not m:
                return {"fehler": f"Markt '{args['markt']}' nicht gefunden"}, None
            tf = self._tf(args.get("timeframe"), context)
            return {"ok": True, "markt": m.name, "timeframe": tf}, {"type": "show_chart", "symbol": m.symbol, "tf": tf}
        return {"fehler": "unbekanntes Werkzeug"}, None

    @staticmethod
    def _compact(r: dict) -> dict:
        price = r.get("price")
        return {"markt": r["name"], "symbol": r["symbol"], "tf": r["tf"], "preis": float(f"{price:.6g}") if price else None,
                "veraenderung_24h_prozent": round(r["change_24h"], 2) if r.get("change_24h") is not None else None,
                "trend": TREND_DE.get(r.get("trend"), r.get("trend")), "score": r.get("net_score"),
                "signal": {"bull": "long", "bear": "short"}.get(r.get("signal")),
                "faktoren_bullisch": len(r.get("bull_factors") or []), "faktoren_baerisch": len(r.get("bear_factors") or [])}

    def _detail(self, r: dict) -> dict:
        d = self._compact(r)
        d["kriterien"] = [{"name": f["label"], "richtung": f["direction"], "aktiv": f["active"], "befund": f["text"]}
                          for f in r.get("findings", [])]
        if r.get("plan"):
            d["handelsplan"] = {k: r["plan"][k] for k in ("entry", "sl", "tp1", "tp2", "crv_tp2")}
        return d

    # ------------------------------------------------------------------ Claude
    def ask(self, message: str, history: list[dict], context: dict) -> dict:
        if self.has_claude:
            try:
                return self._ask_claude(message, history, context)
            except Exception as e:  # noqa: BLE001
                log.warning("Claude-Anfrage fehlgeschlagen: %s", e)
                out = self._local(message, context)
                out["reply"] = "Claude ist gerade nicht erreichbar, ich antworte mit den eingebauten Befehlen. " + out["reply"]
                return out
        return self._local(message, context)

    def _ask_claude(self, message: str, history: list[dict], context: dict) -> dict:
        key = self.cfg["secrets"]["anthropic_api_key"]
        a = self.cfg["assistant"]
        system = SYSTEM
        if context.get("symbol"):
            m = self.sc.find_market(context["symbol"])
            if m:
                system += f"\nIm Dashboard ist gerade {m.name} ({m.symbol}) im {TF_LABEL.get(context.get('tf'), context.get('tf'))}-Chart geöffnet."
        msgs = [{"role": h["role"], "content": str(h["content"])[:2000]}
                for h in history[-10:] if h.get("role") in ("user", "assistant") and h.get("content")]
        while msgs and msgs[0]["role"] != "user":
            msgs.pop(0)
        msgs.append({"role": "user", "content": message})
        actions = []
        for _ in range(6):
            r = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                json={"model": a["model"], "max_tokens": int(a["max_tokens"]), "system": system, "tools": TOOLS, "messages": msgs},
                timeout=60,
            )
            if not r.ok:
                raise RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
            data = r.json()
            content = data.get("content", [])
            if data.get("stop_reason") == "tool_use":
                msgs.append({"role": "assistant", "content": content})
                results = []
                for block in content:
                    if block.get("type") != "tool_use":
                        continue
                    try:
                        out, action = self.run_tool(block["name"], block.get("input") or {}, context)
                    except Exception as e:  # noqa: BLE001
                        out, action = {"fehler": str(e)}, None
                    if action:
                        actions.append(action)
                    results.append({"type": "tool_result", "tool_use_id": block["id"],
                                    "content": json.dumps(out, ensure_ascii=False, default=str)[:12000]})
                msgs.append({"role": "user", "content": results})
                continue
            text = " ".join(b.get("text", "") for b in content if b.get("type") == "text").strip()
            return {"reply": text or "Dazu habe ich keine Antwort.", "actions": actions, "mode": "claude"}
        return {"reply": "Das hat zu viele Schritte gebraucht. Frag bitte etwas genauer.", "actions": actions, "mode": "claude"}

    # ------------------------------------------------------------------ eingebaute Befehle
    def _speak_market(self, r: dict) -> str:
        P = fmt.price
        tf = TF_SAY.get(r["tf"], r["tf"])
        parts = [f"{r['name']} {tf} steht bei {P(r['price'])}" if r.get("price") else f"{r['name']} {tf}"]
        if r.get("change_24h") is not None:
            parts[0] += f", {'plus' if r['change_24h'] >= 0 else 'minus'} {fmt.num(abs(r['change_24h']))} Prozent in 24 Stunden."
        else:
            parts[0] += "."
        bull, bear = len(r.get("bull_factors") or []), len(r.get("bear_factors") or [])
        fw = lambda n: f"{n} Faktor" if n == 1 else f"{n} Faktoren"  # noqa: E731
        parts.append(f"Trend: {TREND_DE.get(r.get('trend'), 'unklar')}. {fw(bull)} bullisch, {fw(bear)} bärisch.")
        if r.get("signal") and r.get("plan"):
            p = r["plan"]
            parts.append(f"Es gibt ein {'Long' if r['signal'] == 'bull' else 'Short'}-Signal: Einstieg {P(p['entry'])}, "
                         f"Stop-Loss {P(p['sl'])}, erstes Ziel {P(p['tp1'])}.")
        active = [f for f in r.get("findings", []) if f["active"] and f["key"] != "trend"][:2]
        if active:
            parts.append(" ".join(f"{f['text']}." for f in active))
        return " ".join(parts)

    def _local(self, message: str, context: dict) -> dict:
        t = message.lower().replace("ß", "ss")
        tf = None
        for pat, val in ((r"(15|fünfzehn)\s*-?\s*min|viertelstunde", "15m"),
                         (r"(4|vier)\s*-?\s*(std|stunde)", "4h"),
                         (r"(\b1|\beine?)\s*-?\s*(std|stunde)|stündlich|stundenchart|stunden-chart", "1h"),
                         (r"tages|daily|\btag\b|1d", "1d")):
            if re.search(pat, t):
                tf = val
                break
        tf = self._tf(tf, context)

        if re.search(r"hilfe|was kannst du|befehle", t):
            return self._reply("Frag mich zum Beispiel: Zeig mir Bitcoin im 4-Stunden-Chart. Gibt es Signale? "
                               "Wie ist der Fear and Greed Index? Was gibt es Neues? Wie ist die Trefferquote?")
        if re.search(r"fear|greed|\bangst|\bgier\b|stimmung|sentiment", t):
            f = self.sc.fng
            if not f:
                return self._reply("Der Fear and Greed Index ist noch nicht geladen.")
            return self._reply(f"Der Krypto Fear and Greed Index steht bei {f['value']}, das bedeutet {f['label']}.",
                               [{"type": "show_fng"}])
        if re.search(r"news|nachricht|schlagzeile|neuigkeit|was gibt es neues", t):
            items = self.sc.news[:3]
            if not items:
                return self._reply("Gerade liegen keine Nachrichten vor.")
            return self._reply("Die neuesten Schlagzeilen: " + " ".join(f"{n['source']}: {n['title']}." for n in items),
                               [{"type": "show_news"}])
        if re.search(r"treffer|logbuch|bilanz|statistik|erfolgsquote", t):
            s = self.sc.store.stats()
            if not s["decided"]:
                return self._reply(f"Im Logbuch stehen {s['total']} Signale, davon ist noch keins abgeschlossen.")
            return self._reply(f"Von {s['decided']} abgeschlossenen Signalen haben {s['tp1'] + s['tp2']} ein Ziel erreicht, "
                               f"das sind {fmt.num(s['win_rate'])} Prozent. {s['open']} Signale laufen noch.",
                               [{"type": "show_log"}])
        m = self.sc.find_market_in_text(t)
        if m:
            row = self.sc.results.get((m.symbol, tf))
            if not row or row.get("error"):
                try:
                    row = self._analysis(m.symbol, tf)
                except Exception:  # noqa: BLE001
                    row = None
            action = [{"type": "show_chart", "symbol": m.symbol, "tf": tf}]
            if not row or "fehler" in row or row.get("error"):
                return self._reply(f"Ich öffne {m.name}. Die Analyse ist gerade nicht verfügbar.", action)
            return self._reply(self._speak_market(row), action)
        if "signal" in t:
            rows = [r for r in self.sc.overview() if r.get("signal")]
            if not rows:
                return self._reply("Gerade gibt es kein aktives Signal. Der Scanner prüft weiter.")
            top = rows[:4]
            txt = "; ".join(f"{r['name']} {TF_SAY.get(r['tf'], r['tf'])} {'Long' if r['signal'] == 'bull' else 'Short'}" for r in top)
            return self._reply(f"Aktuell {len(rows)} Signal{'e' if len(rows) > 1 else ''}: {txt}.",
                               [{"type": "show_chart", "symbol": top[0]["symbol"], "tf": top[0]["tf"]}])
        return self._reply("Das habe ich nicht verstanden. Sag zum Beispiel: Zeig mir Solana im 4-Stunden-Chart, "
                           "oder: Gibt es Signale?")

    def _reply(self, text: str, actions: list | None = None) -> dict:
        return {"reply": text, "actions": actions or [], "mode": "befehle"}


def criteria_names() -> list[str]:
    return list(LABELS.values())
