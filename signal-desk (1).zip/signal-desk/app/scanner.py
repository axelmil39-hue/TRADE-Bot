"""Der Scanner: prüft rund um die Uhr alle Märkte und Zeiteinheiten,
speichert Signale im Logbuch und verschickt sie per Telegram."""
from __future__ import annotations

import asyncio
import logging
import os
import re
import time
from collections import deque

from . import feeds, telegram_bot
from .analysis.engine import analyze
from .markets import TF_SEC, Market, build_universe, fetch_candles

log = logging.getLogger("signal-desk.scanner")

ALIASES = {
    "gold": "GC=F", "silber": "SI=F", "öl": "CL=F", "oel": "CL=F", "rohöl": "CL=F", "erdöl": "CL=F",
    "wti": "CL=F", "erdgas": "NG=F", "gas": "NG=F", "ripple": "XRP", "ether": "ETH", "doge": "DOGE",
    "binance coin": "BNB", "polygon": "POL", "matic": "POL",
}


class Scanner:
    def __init__(self, cfg: dict, store):
        self.cfg = cfg
        self.store = store
        self.markets: list[Market] = []
        self.results: dict[tuple[str, str], dict] = {}
        self.chart_cache: dict[tuple[str, str], dict] = {}
        self.fng: dict | None = None
        self.news: list[dict] = []
        self.news_errors: list[str] = []
        self.errors: deque = deque(maxlen=50)
        self.sem = asyncio.Semaphore(int(cfg.get("concurrency", 6)))
        self.universe_at = 0.0
        self.status = {"started_at": int(time.time()), "last_scan_at": None, "last_scan_seconds": None,
                       "scans": 0, "scanning": False, "markets": 0}

    # -------------------------------------------------------------- Märkte
    async def refresh_universe(self) -> None:
        markets = await asyncio.to_thread(build_universe, self.cfg)
        if markets:
            self.markets = markets
            self.universe_at = time.time()
            crypto = sum(m.kind == "crypto" for m in markets)
            if not self.cfg["demo"] and crypto < int(self.cfg["universe"].get("top_n", 100)) * 0.5:
                self.universe_at -= 86400 - 900  # Fallback-Liste: in 15 Minuten neu versuchen
            self.status["markets"] = len(markets)
            log.info("%d Märkte im Scanner", len(markets))

    def find_market(self, query: str) -> Market | None:
        if not query:
            return None
        q = query.strip().lower()
        for m in self.markets:
            if q in (m.symbol.lower(), m.base.lower(), m.name.lower()):
                return m
        target = ALIASES.get(q)
        if target:
            for m in self.markets:
                if target.lower() in (m.symbol.lower(), m.base.lower()):
                    return m
        for m in self.markets:  # Teiltreffer, z. B. "bitcoin cash"
            if q in m.name.lower():
                return m
        return None

    def find_market_in_text(self, text: str) -> Market | None:
        t = " " + re.sub(r"[^\wäöüß=]+", " ", text.lower()) + " "
        best, best_len = None, 0
        names = []
        for m in self.markets:
            for alias in {m.name.lower(), m.base.lower(), m.symbol.lower()}:
                if len(alias) >= 2:
                    names.append((alias, m))
        for alias, target in ALIASES.items():
            m = self.find_market(target)
            if m:
                names.append((alias, m))
        for alias, m in names:
            if f" {alias} " in t and len(alias) > best_len:
                best, best_len = m, len(alias)
        return best

    # -------------------------------------------------------------- Kerzen
    async def fetch(self, m: Market, tf: str) -> list[dict]:
        async with self.sem:
            return await asyncio.to_thread(fetch_candles, m, tf, int(self.cfg["candles"]), self.cfg)

    async def chart_candles(self, m: Market, tf: str) -> list[dict]:
        key = (m.symbol, tf)
        c = self.chart_cache.get(key)
        if c and time.time() - c["at"] < 20:
            return c["candles"]
        candles = await self.fetch(m, tf)
        self.chart_cache[key] = {"at": time.time(), "candles": candles}
        if len(self.chart_cache) > 40:  # Speicher klein halten
            oldest = sorted(self.chart_cache, key=lambda k: self.chart_cache[k]["at"])[:10]
            for k in oldest:
                self.chart_cache.pop(k, None)
        return candles

    def analyze_candles(self, candles: list[dict]) -> dict:
        closed = [k for k in candles if not k.get("live")][-int(self.cfg["candles"]):]
        return analyze(closed, self.cfg.get("weights"), self.cfg.get("signal"))

    # -------------------------------------------------------------- Scan
    def needs_scan(self, m: Market, tf: str) -> bool:
        s = self.results.get((m.symbol, tf))
        if not s or s.get("error"):
            return True
        return time.time() >= s["candle_time"] + 2 * TF_SEC[tf] + 5

    async def scan_one(self, m: Market, tf: str) -> None:
        key = (m.symbol, tf)
        try:
            candles = await self.fetch(m, tf)
            res = await asyncio.to_thread(self.analyze_candles, candles)
            if not res["ok"]:
                self.results[key] = self._base(m, tf, candles) | {"error": res["error"]}
                return
            self.results[key] = self.summarize(m, tf, candles, res)
            closed = [k for k in candles if not k.get("live")]
            self.store.update_outcomes(m.symbol, tf, closed, int(self.cfg["signal"].get("expire_candles", 60)))
            if res["signal"]:
                sig = self.store.add_signal(m, tf, res)
                if sig:
                    log.info("Neues Signal: %s %s %s", m.symbol, tf, res["signal"])
                    await asyncio.to_thread(self.notify, sig)
        except Exception as e:  # noqa: BLE001
            msg = f"{m.symbol} {tf}: {type(e).__name__}: {e}"
            self.errors.append({"t": int(time.time()), "msg": msg[:300]})
            log.info("Scan-Fehler %s", msg)
            if key not in self.results:
                self.results[key] = self._base(m, tf, []) | {"error": str(e)[:200]}

    async def scan_all(self) -> None:
        self.status["scanning"] = True
        t0 = time.time()
        jobs = [self.scan_one(m, tf) for m in list(self.markets) for tf in self.cfg["timeframes"] if self.needs_scan(m, tf)]
        await asyncio.gather(*jobs)
        self.status.update(scanning=False, last_scan_at=int(time.time()), last_scan_seconds=round(time.time() - t0, 1),
                           last_scan_jobs=len(jobs))
        self.status["scans"] += 1

    async def run(self) -> None:
        while True:
            try:
                if not self.markets or time.time() - self.universe_at > 86400:
                    await self.refresh_universe()
                await self.scan_all()
            except Exception as e:  # noqa: BLE001
                log.exception("Scan-Schleife: %s", e)
            await asyncio.sleep(max(30, float(self.cfg["scan_interval_minutes"]) * 60))

    def _base(self, m: Market, tf: str, candles: list[dict]) -> dict:
        price, change = None, None
        if candles:
            price = candles[-1]["c"]
            k = max(1, 86400 // TF_SEC[tf])
            ref = candles[-1 - k]["c"] if len(candles) > k else candles[0]["c"]
            change = (price / ref - 1) * 100 if ref else None
        return {"symbol": m.symbol, "name": m.name, "kind": m.kind, "base": m.base, "rank": m.rank, "tf": tf,
                "price": price, "change_24h": change, "analyzed_at": int(time.time())}

    def summarize(self, m: Market, tf: str, candles: list[dict], res: dict) -> dict:
        return self._base(m, tf, candles) | {
            "candle_time": res["candle_time"],
            "trend": res["trend"],
            "net_score": res["net_score"],
            "bull_score": res["bull_score"],
            "bear_score": res["bear_score"],
            "bull_factors": res["bull_factors"],
            "bear_factors": res["bear_factors"],
            "signal": res["signal"],
            "plan": res["plan"],
            "findings": [{k: f[k] for k in ("key", "label", "direction", "active", "trigger", "state", "text")}
                         for f in res["findings"]],
        }

    # -------------------------------------------------------------- Telegram
    def notify(self, sig: dict) -> None:
        tg, sec = self.cfg["telegram"], self.cfg["secrets"]
        if not (tg.get("enabled") and sec["telegram_token"] and sec["telegram_chat_id"]):
            return
        if sig["timeframe"] not in tg.get("timeframes", []) or len(sig["factors"]) < int(tg.get("min_factors", 3)):
            return
        url = os.environ.get("PUBLIC_URL", "")
        if url:
            url = f"{url.rstrip('/')}/?symbol={sig['symbol']}&tf={sig['timeframe']}"
        telegram_bot.send(sec["telegram_token"], sec["telegram_chat_id"], telegram_bot.format_signal(sig, self.fng, url))

    # -------------------------------------------------------------- News + Stimmung
    async def news_loop(self) -> None:
        while True:
            try:
                if self.cfg["demo"]:
                    self.news, self.news_errors = feeds.demo_news(), []
                else:
                    self.news, self.news_errors = await asyncio.to_thread(
                        feeds.fetch_news, self.cfg["news"]["feeds"], int(self.cfg["news"]["max_items"]))
            except Exception as e:  # noqa: BLE001
                self.news_errors = [str(e)]
            await asyncio.sleep(max(60, float(self.cfg["news"]["refresh_minutes"]) * 60))

    async def fng_loop(self) -> None:
        while True:
            try:
                self.fng = feeds.demo_fear_greed() if self.cfg["demo"] else await asyncio.to_thread(feeds.fetch_fear_greed, 90)
            except Exception as e:  # noqa: BLE001
                self.errors.append({"t": int(time.time()), "msg": f"Fear & Greed: {e}"[:300]})
            await asyncio.sleep(900)

    # -------------------------------------------------------------- Abfragen
    def overview(self) -> list[dict]:
        rows = list(self.results.values())
        rows.sort(key=lambda r: (r.get("signal") is None, -abs(r.get("net_score") or 0)))
        return rows
