"""Signale per Telegram verschicken (an dich, eine Gruppe oder deinen Kanal)."""
from __future__ import annotations

import html
import logging

import requests

from .analysis import fmt
from .analysis.patterns import LABELS
from .markets import TF_LABEL

log = logging.getLogger("signal-desk.telegram")


def format_signal(sig: dict, fng: dict | None, dashboard_url: str = "") -> str:
    long = sig["direction"] == "bull"
    head = "🟢 <b>LONG-Signal</b>" if long else "🔴 <b>SHORT-Signal</b>"
    P = fmt.price
    lines = [
        f"{head}  {html.escape(sig['name'])} ({html.escape(sig['symbol'])}), {TF_LABEL.get(sig['timeframe'], sig['timeframe'])}",
        "",
        f"<b>{len(sig['factors'])} Faktoren</b> (Score {fmt.num(sig['score'])}):",
    ]
    for key, txt in zip(sig["factors"], sig["texts"]):
        lines.append(f"• {html.escape(LABELS.get(key, key))}: {html.escape(txt)}")
    lines += [
        "",
        f"Einstieg: <code>{P(sig['entry'])}</code>",
        f"Stop-Loss: <code>{P(sig['sl'])}</code>",
        f"TP1: <code>{P(sig['tp1'])}</code>   TP2: <code>{P(sig['tp2'])}</code>",
    ]
    if fng:
        lines.append(f"Fear &amp; Greed: {fng['value']} ({html.escape(fng['label'])})")
    if dashboard_url:
        lines.append(f'<a href="{html.escape(dashboard_url)}">Im Dashboard ansehen</a>')
    lines.append("<i>Keine Anlageberatung.</i>")
    return "\n".join(lines)


def send(token: str, chat_id: str, text: str) -> bool:
    try:
        r = requests.post(f"https://api.telegram.org/bot{token}/sendMessage",
                          json={"chat_id": chat_id, "text": text, "parse_mode": "HTML",
                                "disable_web_page_preview": True}, timeout=15)
        if not r.ok:
            log.warning("Telegram-Fehler %s: %s", r.status_code, r.text[:200])
        return r.ok
    except Exception as e:  # noqa: BLE001
        log.warning("Telegram nicht erreichbar: %s", e)
        return False
