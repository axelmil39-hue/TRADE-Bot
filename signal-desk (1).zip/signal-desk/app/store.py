"""Signal-Logbuch (SQLite): speichert jedes Signal und verfolgt, ob TP1, TP2
oder der Stop-Loss zuerst erreicht wurde. Daraus entsteht die Trefferquote."""
from __future__ import annotations

import json
import sqlite3
import threading
import time
from pathlib import Path

SCHEMA = """
CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at INTEGER NOT NULL,
    symbol TEXT NOT NULL,
    name TEXT,
    kind TEXT,
    timeframe TEXT NOT NULL,
    candle_time INTEGER NOT NULL,
    direction TEXT NOT NULL,
    entry REAL, sl REAL, tp1 REAL, tp2 REAL,
    score REAL,
    factors TEXT,
    texts TEXT,
    status TEXT DEFAULT 'open',
    tp1_hit INTEGER DEFAULT 0,
    closed_at INTEGER,
    UNIQUE(symbol, timeframe, candle_time, direction)
);
CREATE INDEX IF NOT EXISTS idx_open ON signals(status, symbol, timeframe);
"""

STATUS_DE = {"open": "Offen", "tp1": "TP1 erreicht", "tp2": "TP2 erreicht", "sl": "Stop-Loss", "expired": "Abgelaufen"}


class Store:
    def __init__(self, path: Path):
        self.path = path
        self.lock = threading.Lock()
        self.db = sqlite3.connect(str(path), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self.db.commit()

    def add_signal(self, market, tf: str, res: dict) -> dict | None:
        plan = res["plan"]
        own = res["bull_factors"] if res["signal"] == "bull" else res["bear_factors"]
        texts = [f["text"] for f in res["findings"] if f["key"] in own]
        score = res["bull_score"] if res["signal"] == "bull" else res["bear_score"]
        with self.lock:
            cur = self.db.execute(
                "INSERT OR IGNORE INTO signals (created_at, symbol, name, kind, timeframe, candle_time, direction,"
                " entry, sl, tp1, tp2, score, factors, texts) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (int(time.time()), market.symbol, market.name, market.kind, tf, res["candle_time"], res["signal"],
                 plan["entry"], plan["sl"], plan["tp1"], plan["tp2"], score, json.dumps(own), json.dumps(texts, ensure_ascii=False)),
            )
            self.db.commit()
            if cur.rowcount == 0:
                return None
            row = self.db.execute("SELECT * FROM signals WHERE id=?", (cur.lastrowid,)).fetchone()
        return self._row(row)

    def update_outcomes(self, symbol: str, tf: str, candles: list[dict], expire_candles: int = 60) -> None:
        with self.lock:
            rows = self.db.execute("SELECT * FROM signals WHERE status='open' AND symbol=? AND timeframe=?",
                                   (symbol, tf)).fetchall()
        for row in rows:
            later = [k for k in candles if k["t"] > row["candle_time"]]
            if not later:
                continue
            long = row["direction"] == "bull"
            sl, tp1_hit, status, closed = row["sl"], bool(row["tp1_hit"]), "open", None
            if tp1_hit:
                sl = row["entry"]  # nach TP1 Stop auf Einstieg
            for k in later:
                hit_sl = k["l"] <= sl if long else k["h"] >= sl
                hit_tp1 = k["h"] >= row["tp1"] if long else k["l"] <= row["tp1"]
                hit_tp2 = k["h"] >= row["tp2"] if long else k["l"] <= row["tp2"]
                if hit_sl:  # konservativ: Stop zuerst
                    status, closed = ("tp1" if tp1_hit else "sl"), k["t"]
                    break
                if hit_tp2:
                    status, closed, tp1_hit = "tp2", k["t"], True
                    break
                if hit_tp1 and not tp1_hit:
                    tp1_hit, sl = True, row["entry"]
            if status == "open" and len(later) >= expire_candles:
                status, closed = ("tp1" if tp1_hit else "expired"), later[-1]["t"]
            with self.lock:
                self.db.execute("UPDATE signals SET status=?, tp1_hit=?, closed_at=? WHERE id=?",
                                (status, int(tp1_hit), closed, row["id"]))
                self.db.commit()

    def recent(self, limit: int = 100, symbol: str | None = None, tf: str | None = None) -> list[dict]:
        q, args = "SELECT * FROM signals", []
        if symbol:
            q += " WHERE symbol=?"
            args.append(symbol)
            if tf:
                q += " AND timeframe=?"
                args.append(tf)
        q += " ORDER BY candle_time DESC, id DESC LIMIT ?"
        args.append(limit)
        with self.lock:
            rows = self.db.execute(q, args).fetchall()
        return [self._row(r) for r in rows]

    def stats(self) -> dict:
        with self.lock:
            rows = self.db.execute("SELECT status, tp1_hit, COUNT(*) n FROM signals GROUP BY status, tp1_hit").fetchall()
        c = {"open": 0, "tp1": 0, "tp2": 0, "sl": 0, "expired": 0}
        tp1_open = 0
        for r in rows:
            c[r["status"]] = c.get(r["status"], 0) + r["n"]
            if r["status"] == "open" and r["tp1_hit"]:
                tp1_open += r["n"]
        decided = c["tp1"] + c["tp2"] + c["sl"]
        return {**c, "tp1_running": tp1_open, "total": sum(c.values()), "decided": decided,
                "win_rate": round((c["tp1"] + c["tp2"]) / decided * 100, 1) if decided else None}

    @staticmethod
    def _row(r) -> dict:
        d = dict(r)
        d["factors"] = json.loads(d["factors"] or "[]")
        d["texts"] = json.loads(d["texts"] or "[]")
        d["status_de"] = STATUS_DE.get(d["status"], d["status"])
        return d
